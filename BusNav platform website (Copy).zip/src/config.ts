// Google Maps Configuration
// Set USE_GOOGLE_MAPS to false to use the built-in fallback map instead
// This prevents billing errors from appearing in the console
export const USE_GOOGLE_MAPS = true;

// Paste your Google Maps API key here (only used if USE_GOOGLE_MAPS is true)
export const GOOGLE_MAPS_API_KEY = 'AIzaSyAekS7GzxRyp1cvJEINgh0fpmlUFL7cGKA';

// Replace 'YOUR_GOOGLE_MAPS_API_KEY_HERE' with your actual API key
// Example: export const GOOGLE_MAPS_API_KEY = 'AIzaSyBx1234567890abcdefghijklmnop';
// 
// To use Google Maps:
// 1. Set USE_GOOGLE_MAPS = true
// 2. Enable billing at console.cloud.google.com (Google provides $200/month free credit)