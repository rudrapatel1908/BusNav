# BusNav - Supabase Backend Setup Instructions

## 🚀 Quick Start Guide

### Step 1: Set Up the Database

1. **Open Supabase SQL Editor**
   - Go to: https://supabase.com/dashboard/project/_/sql
   - Click "New Query"

2. **Run the Database Schema**
   - Open the file: `/supabase/functions/server/init-database.tsx`
   - Copy the entire SQL code from the `DATABASE_SCHEMA` constant
   - Paste it into the SQL Editor
   - Click "Run" to execute

3. **Verify Tables Created**
   - Go to: https://supabase.com/dashboard/project/_/editor
   - You should see these tables:
     - `profiles` - User accounts
     - `universities` - 15 Indian universities
     - `drivers` - 90 drivers (6 per university)
     - `buses` - 90 buses (6 per university)
     - `bus_locations` - Real-time bus tracking
     - `feedback` - Driver ratings and reviews
     - `user_pickup_routes` - User's selected pickup locations

### Step 2: Enable Row Level Security

The SQL script automatically enables RLS (Row Level Security) with these policies:

- ✅ **Users can only view/edit their own profile**
- ✅ **Anyone can view universities, buses, drivers, and locations** (public data)
- ✅ **Only authenticated users can submit feedback**
- ✅ **Users can only manage their own pickup routes**

### Step 3: Test the Setup

Your BusNav app is now ready! The backend includes:

## 📡 Available API Endpoints

### Authentication
- `POST /make-server-8828d0dd/auth/signup` - Create new account

### Universities
- `GET /make-server-8828d0dd/universities` - Get all universities
- `GET /make-server-8828d0dd/universities/:id` - Get university with buses

### Bus Tracking
- `POST /make-server-8828d0dd/buses/:id/location` - Update bus location
- `GET /make-server-8828d0dd/universities/:id/bus-locations` - Get all bus locations

### User Preferences (Requires Auth)
- `POST /make-server-8828d0dd/user/university` - Save selected university
- `POST /make-server-8828d0dd/user/location` - Save home location
- `GET /make-server-8828d0dd/user/profile` - Get user profile

### Pickup Routes (Requires Auth)
- `POST /make-server-8828d0dd/user/pickup-route` - Save pickup route
- `GET /make-server-8828d0dd/user/pickup-route` - Get saved route

### Feedback (Requires Auth)
- `POST /make-server-8828d0dd/feedback` - Submit driver feedback
- `GET /make-server-8828d0dd/drivers/:id/feedback` - Get driver reviews

## 🗄️ Database Schema

### profiles
- User accounts (students and parents)
- Stores: email, name, role, selected university, home location

### universities
- 15 major Indian universities preloaded
- Includes: IIT Delhi, IIT Bombay, IIT Madras, DU, JNU, etc.

### drivers
- 90 Indian driver names
- Phone numbers and optional photos

### buses
- 6 buses per university (90 total)
- Linked to drivers and universities

### bus_locations
- Real-time GPS coordinates
- Updates every 5 seconds

### feedback
- User ratings (1-5 stars)
- Comments for drivers

### user_pickup_routes
- Saved pickup locations
- Selected bus for route

## 🔐 Authentication Flow

### Sign Up
```typescript
const response = await fetch(`${SERVER_URL}/auth/signup`, {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    email: 'student@example.com',
    password: 'password123',
    name: 'John Doe',
    role: 'student' // or 'parent'
  })
});
```

### Sign In
```typescript
import { createClient } from './utils/supabase/client';

const supabase = createClient();
const { data, error } = await supabase.auth.signInWithPassword({
  email: 'student@example.com',
  password: 'password123'
});

// Store the access token
const accessToken = data.session?.access_token;
```

### Authenticated Requests
```typescript
const response = await fetch(`${SERVER_URL}/user/profile`, {
  headers: {
    'Authorization': `Bearer ${accessToken}`
  }
});
```

## 📊 Preloaded Data

### 15 Universities
- IIT Delhi, IIT Bombay, IIT Madras
- Delhi University, JNU, Mumbai University
- Anna University, Bangalore University
- Jadavpur University, Pune University
- Hyderabad University, AMU, BHU
- Calcutta University, Jamia Millia Islamia

### 90 Buses (6 per university)
- Format: `IIT Delhi-1`, `IIT Delhi-2`, etc.
- Each bus has a dedicated driver

### 90 Indian Drivers
- Realistic Indian names: Rajesh Kumar, Suresh Sharma, etc.
- Phone numbers in format: +91 9000000001

## 🎯 Next Steps

1. ✅ Run the SQL script (Step 1)
2. ✅ Integrate the frontend with authentication
3. ✅ Connect bus tracking to real-time updates
4. ✅ Add login/signup pages
5. ✅ Test the complete flow

## 💡 Tips

- The database is already seeded with 15 universities and 90 buses
- Bus locations are initialized near each university
- All console errors are logged for easy debugging
- Use the Supabase Dashboard to view and manage data

## 🔧 Troubleshooting

**Tables not created?**
- Make sure you ran the SQL in the SQL Editor, not the Query tool
- Check for error messages in the SQL output

**Authentication not working?**
- Verify email confirmation is disabled (it's set to auto-confirm)
- Check the access token is being passed in headers

**RLS errors?**
- The policies are set up for public read on most tables
- Only user-specific data requires authentication

---

**Your backend is ready!** 🎉

Now integrate the frontend to connect with these endpoints and you'll have a fully functional real-time bus tracking system!
