import { useState, useEffect } from 'react';
import { Bell, BellRing, Check, X, Navigation, Clock } from 'lucide-react';
import { toast } from 'sonner@2.0.3';

interface Notification {
  id: string;
  busId: string;
  route: string;
  distance: number;
  timestamp: Date;
  read: boolean;
  type: 'proximity' | 'arrival' | 'delay';
}

interface NotificationsProps {
  userLocation: { lat: number; lng: number };
}

// Mock notification generator
const generateMockNotifications = (): Notification[] => [
  {
    id: '1',
    busId: 'BUS-001',
    route: 'Route A - Main Campus Loop',
    distance: 0.8,
    timestamp: new Date(Date.now() - 5 * 60000),
    read: false,
    type: 'proximity',
  },
  {
    id: '2',
    busId: 'BUS-003',
    route: 'Route C - Downtown Express',
    distance: 0.95,
    timestamp: new Date(Date.now() - 15 * 60000),
    read: false,
    type: 'proximity',
  },
  {
    id: '3',
    busId: 'BUS-002',
    route: 'Route B - Residential Area',
    distance: 0.2,
    timestamp: new Date(Date.now() - 30 * 60000),
    read: true,
    type: 'arrival',
  },
  {
    id: '4',
    busId: 'BUS-004',
    route: 'Route D - Sports Complex',
    distance: 1.5,
    timestamp: new Date(Date.now() - 45 * 60000),
    read: true,
    type: 'delay',
  },
];

export function Notifications({ userLocation }: NotificationsProps) {
  const [notifications, setNotifications] = useState<Notification[]>(generateMockNotifications());
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  const [proximityThreshold, setProximityThreshold] = useState(1.0);

  // Simulate new notifications
  useEffect(() => {
    if (!notificationsEnabled) return;

    const interval = setInterval(() => {
      // 30% chance of new notification every 10 seconds
      if (Math.random() < 0.3) {
        const busIds = ['BUS-001', 'BUS-002', 'BUS-003', 'BUS-004'];
        const routes = [
          'Route A - Main Campus Loop',
          'Route B - Residential Area',
          'Route C - Downtown Express',
          'Route D - Sports Complex',
        ];
        const types: ('proximity' | 'arrival' | 'delay')[] = ['proximity', 'arrival', 'delay'];

        const randomIndex = Math.floor(Math.random() * busIds.length);
        const newNotification: Notification = {
          id: Date.now().toString(),
          busId: busIds[randomIndex],
          route: routes[randomIndex],
          distance: Math.random() * 1.5,
          timestamp: new Date(),
          read: false,
          type: types[Math.floor(Math.random() * types.length)],
        };

        setNotifications((prev) => [newNotification, ...prev]);

        // Show toast notification
        if (newNotification.distance <= proximityThreshold && newNotification.type === 'proximity') {
          toast.success(`${newNotification.busId} is within ${newNotification.distance.toFixed(2)} km!`, {
            description: newNotification.route,
            duration: 5000,
          });
        }
      }
    }, 10000);

    return () => clearInterval(interval);
  }, [notificationsEnabled, proximityThreshold]);

  const markAsRead = (id: string) => {
    setNotifications((prev) =>
      prev.map((notif) => (notif.id === id ? { ...notif, read: true } : notif))
    );
  };

  const markAllAsRead = () => {
    setNotifications((prev) => prev.map((notif) => ({ ...notif, read: true })));
  };

  const deleteNotification = (id: string) => {
    setNotifications((prev) => prev.filter((notif) => notif.id !== id));
  };

  const clearAll = () => {
    setNotifications([]);
  };

  const unreadCount = notifications.filter((n) => !n.read).length;

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'proximity':
        return '📍';
      case 'arrival':
        return '🚌';
      case 'delay':
        return '⚠️';
      default:
        return '🔔';
    }
  };

  const getNotificationMessage = (notification: Notification) => {
    switch (notification.type) {
      case 'proximity':
        return `is within ${notification.distance.toFixed(2)} km of your location`;
      case 'arrival':
        return `has arrived at your stop`;
      case 'delay':
        return `is experiencing delays`;
      default:
        return '';
    }
  };

  const formatTime = (date: Date) => {
    const now = new Date();
    const diff = Math.floor((now.getTime() - date.getTime()) / 60000);
    
    if (diff < 1) return 'Just now';
    if (diff < 60) return `${diff} min ago`;
    if (diff < 1440) return `${Math.floor(diff / 60)} hours ago`;
    return date.toLocaleDateString();
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Settings Card */}
      <div className="bg-slate-900/60 backdrop-blur-xl rounded-2xl shadow-xl p-6 border border-white/10">
        <h2 className="text-white mb-5 flex items-center gap-2">
          <span>Notification Settings</span>
          {notificationsEnabled && (
            <div className="flex items-center gap-1.5 text-xs">
              <div className="w-2 h-2 bg-green-400 rounded-full live-indicator"></div>
              <span className="text-green-400">Enabled</span>
            </div>
          )}
        </h2>
        
        <div className="space-y-5">
          <div className="flex items-center justify-between p-4 bg-white/[0.02] rounded-xl border border-white/10 hover:border-cyan-400/30 transition-all">
            <div>
              <h3 className="font-medium text-white mb-1">Enable Notifications</h3>
              <p className="text-sm text-blue-200/60">
                Get notified when buses are near your location
              </p>
            </div>
            <button
              onClick={() => setNotificationsEnabled(!notificationsEnabled)}
              className={`relative inline-flex h-6 w-11 items-center rounded-full transition-all duration-200 shadow-lg $\{
                notificationsEnabled ? 'bg-gradient-to-r from-cyan-500 to-blue-500 shadow-cyan-500/20' : 'bg-slate-700'
              }`}
            >
              <span
                className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform shadow-md $\{
                  notificationsEnabled ? 'translate-x-6' : 'translate-x-1'
                }`}
              />
            </button>
          </div>

          <div className="p-4 bg-white/[0.02] rounded-xl border border-white/10">
            <label htmlFor="threshold" className="block font-medium text-white mb-3 flex items-center justify-between">
              <span>Proximity Threshold</span>
              <span className="text-cyan-400 text-sm">{proximityThreshold.toFixed(1)} km</span>
            </label>
            <input
              id="threshold"
              type="range"
              min="0.5"
              max="3"
              step="0.1"
              value={proximityThreshold}
              onChange={(e) => setProximityThreshold(parseFloat(e.target.value))}
              className="w-full h-2 bg-white/10 rounded-lg appearance-none cursor-pointer [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-4 [&::-webkit-slider-thumb]:h-4 [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-gradient-to-r [&::-webkit-slider-thumb]:from-cyan-500 [&::-webkit-slider-thumb]:to-blue-500 [&::-webkit-slider-thumb]:shadow-lg [&::-webkit-slider-thumb]:shadow-cyan-500/30 [&::-webkit-slider-thumb]:cursor-pointer hover:[&::-webkit-slider-thumb]:scale-110 [&::-webkit-slider-thumb]:transition-transform"
            />
            <p className="text-xs text-blue-200/50 mt-2">
              You'll be notified when a bus is within this distance
            </p>
          </div>

          <div className="pt-4 border-t border-white/10">
            <h3 className="font-medium text-white mb-3">Notification Channels</h3>
            <div className="space-y-2.5">
              <label className="flex items-center gap-3 text-sm py-2 px-3 rounded-lg hover:bg-white/[0.02] transition-colors cursor-pointer group">
                <input type="checkbox" checked readOnly className="rounded border-white/20 bg-white/5 text-cyan-500 focus:ring-cyan-500 focus:ring-offset-0 cursor-pointer" />
                <span className="text-blue-200/70 group-hover:text-blue-200/90 transition-colors">In-App Notifications</span>
              </label>
              <label className="flex items-center gap-3 text-sm py-2 px-3 rounded-lg hover:bg-white/[0.02] transition-colors cursor-pointer group">
                <input type="checkbox" defaultChecked className="rounded border-white/20 bg-white/5 text-cyan-500 focus:ring-cyan-500 focus:ring-offset-0 cursor-pointer" />
                <span className="text-blue-200/70 group-hover:text-blue-200/90 transition-colors">Email Notifications</span>
              </label>
              <label className="flex items-center gap-3 text-sm py-2 px-3 rounded-lg hover:bg-white/[0.02] transition-colors cursor-pointer group">
                <input type="checkbox" defaultChecked className="rounded border-white/20 bg-white/5 text-cyan-500 focus:ring-cyan-500 focus:ring-offset-0 cursor-pointer" />
                <span className="text-blue-200/70 group-hover:text-blue-200/90 transition-colors">SMS Notifications (Parent)</span>
              </label>
              <label className="flex items-center gap-3 text-sm py-2 px-3 rounded-lg hover:bg-white/[0.02] transition-colors cursor-pointer group">
                <input type="checkbox" className="rounded border-white/20 bg-white/5 text-cyan-500 focus:ring-cyan-500 focus:ring-offset-0 cursor-pointer" />
                <span className="text-blue-200/70 group-hover:text-blue-200/90 transition-colors">Push Notifications</span>
              </label>
            </div>
          </div>
        </div>
      </div>

      {/* Notifications List */}
      <div className="bg-slate-900/60 backdrop-blur-xl rounded-2xl shadow-xl border border-white/10 overflow-hidden">
        <div className="p-6 border-b border-white/10">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <h2 className="text-white">Notifications</h2>
              {unreadCount > 0 && (
                <span className="px-2.5 py-1 bg-gradient-to-r from-red-500 to-pink-500 text-white text-xs rounded-full shadow-lg shadow-red-500/20 animate-pulse-glow font-medium">
                  {unreadCount} new
                </span>
              )}
            </div>
            <div className="flex gap-3">
              {unreadCount > 0 && (
                <button
                  onClick={markAllAsRead}
                  className="text-sm text-cyan-400 hover:text-cyan-300 font-medium transition-colors flex items-center gap-1.5"
                >
                  <Check className="w-4 h-4" />
                  Mark all read
                </button>
              )}
              {notifications.length > 0 && (
                <button
                  onClick={clearAll}
                  className="text-sm text-blue-200/60 hover:text-blue-200/90 font-medium transition-colors flex items-center gap-1.5"
                >
                  <X className="w-4 h-4" />
                  Clear all
                </button>
              )}
            </div>
          </div>
        </div>

        {notifications.length === 0 ? (
          <div className="p-16 text-center animate-fade-in">
            <div className="w-16 h-16 bg-blue-500/10 rounded-full flex items-center justify-center mx-auto mb-4 border border-blue-400/20">
              <Bell className="w-8 h-8 text-blue-400/60" />
            </div>
            <p className="text-blue-200/60 mb-1">No notifications yet</p>
            <p className="text-sm text-blue-200/40">
              You'll be notified when buses are near your location
            </p>
          </div>
        ) : (
          <div className="divide-y divide-white/10">
            {notifications.map((notification, index) => (
              <div
                key={notification.id}
                className={`p-5 hover:bg-white/[0.02] transition-all duration-200 animate-slide-in $\{
                  !notification.read ? 'bg-cyan-500/5' : ''
                }`}
                style={{ animationDelay: `${index * 30}ms` }}
              >
                <div className="flex items-start gap-4">
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 shadow-lg $\{
                    notification.type === 'proximity' 
                      ? 'bg-cyan-500/20 text-cyan-400 border border-cyan-400/30' 
                      : notification.type === 'arrival'
                      ? 'bg-green-500/20 text-green-400 border border-green-400/30'
                      : 'bg-yellow-500/20 text-yellow-400 border border-yellow-400/30'
                  }`}>
                    {notification.type === 'proximity' && <Navigation className="w-5 h-5" />}
                    {notification.type === 'arrival' && <BellRing className="w-5 h-5" />}
                    {notification.type === 'delay' && <Clock className="w-5 h-5" />}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-3 mb-1">
                      <div>
                        <h3 className="font-medium text-white flex items-center gap-2">
                          {notification.busId}
                          {!notification.read && (
                            <span className="w-2 h-2 bg-cyan-400 rounded-full animate-pulse-glow"></span>
                          )}
                        </h3>
                        <p className="text-sm text-blue-200/60 mt-0.5">{notification.route}</p>
                      </div>
                      <button
                        onClick={() => deleteNotification(notification.id)}
                        className="text-blue-200/40 hover:text-red-400 transition-colors p-1 hover:bg-red-500/10 rounded-lg"
                        aria-label="Delete notification"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                    <p className="text-sm text-blue-200/80 mb-2">
                      {getNotificationMessage(notification)}
                    </p>
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-blue-200/50">{formatTime(notification.timestamp)}</span>
                      {!notification.read && (
                        <button
                          onClick={() => markAsRead(notification.id)}
                          className="text-xs text-cyan-400 hover:text-cyan-300 font-medium transition-colors"
                        >
                          Mark as read
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}