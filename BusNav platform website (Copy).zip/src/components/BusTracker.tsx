import { useState, useEffect, useMemo } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { MapPin, Navigation, Clock, Users, UserCheck } from "lucide-react";
import { GoogleMap } from "./GoogleMap";

// Indian College/University Locations
const INDIAN_UNIVERSITIES = {
  'SRM AP University': { lat: 16.4381, lng: 80.5980, location: 'Amaravati, Andhra Pradesh' },
  'IIT Madras': { lat: 12.9914, lng: 80.2336, location: 'Chennai, Tamil Nadu' },
  'IIT Delhi': { lat: 28.5450, lng: 77.1920, location: 'New Delhi' },
  'IIT Bombay': { lat: 19.1334, lng: 72.9133, location: 'Mumbai, Maharashtra' },
  'BITS Pilani': { lat: 28.3632, lng: 75.5883, location: 'Pilani, Rajasthan' },
  'VIT Vellore': { lat: 12.9698, lng: 79.1555, location: 'Vellore, Tamil Nadu' },
  'NIT Trichy': { lat: 10.7598, lng: 78.8148, location: 'Tiruchirappalli, Tamil Nadu' },
  'IIIT Hyderabad': { lat: 17.4451, lng: 78.3489, location: 'Hyderabad, Telangana' },
  'IIT Kanpur': { lat: 26.5123, lng: 80.2329, location: 'Kanpur, Uttar Pradesh' },
  'IIT Kharagpur': { lat: 22.3149, lng: 87.3105, location: 'Kharagpur, West Bengal' },
  'Anna University': { lat: 13.0127, lng: 80.2345, location: 'Chennai, Tamil Nadu' },
  'Jadavpur University': { lat: 22.4987, lng: 88.3712, location: 'Kolkata, West Bengal' },
  'Manipal Institute of Technology': { lat: 13.3497, lng: 74.7869, location: 'Manipal, Karnataka' },
  'Delhi University': { lat: 28.6862, lng: 77.2120, location: 'New Delhi' },
  'Amity University': { lat: 28.5448, lng: 77.3373, location: 'Noida, Uttar Pradesh' },
};

interface Bus {
  id: string;
  route: string;
  driver: string;
  capacity: number;
  occupied: number;
  location: { lat: number; lng: number };
  speed: number;
  estimatedArrival: string;
  nextStop: string;
}

interface BusTrackerProps {
  university: string;
  userLocation: { lat: number; lng: number };
  onLocationChange: (location: {
    lat: number;
    lng: number;
  }) => void;
}

// Function to generate pickup location near the college
const generatePickupLocation = (universityLat: number, universityLng: number) => {
  // Place pickup location 0.5-1 km from university
  const angle = Math.random() * 2 * Math.PI;
  const distance = 0.005 + Math.random() * 0.005; // 0.5-1 km
  return {
    lat: universityLat + Math.cos(angle) * distance,
    lng: universityLng + Math.sin(angle) * distance,
  };
};

// Generate buses based on selected university
const generateBuses = (university: string): Bus[] => {
  const universityData = INDIAN_UNIVERSITIES[university as keyof typeof INDIAN_UNIVERSITIES];
  
  if (!universityData) {
    // Default to SRM AP University if not found
    return generateBusesForLocation(INDIAN_UNIVERSITIES['SRM AP University'].lat, INDIAN_UNIVERSITIES['SRM AP University'].lng, university);
  }
  
  return generateBusesForLocation(universityData.lat, universityData.lng, university);
};

// Generate buses around a specific location
const generateBusesForLocation = (centerLat: number, centerLng: number, universityName: string): Bus[] => {
  const routes = [
    { name: 'Main Campus Loop', stops: ['Main Gate', 'Engineering Block', 'Library', 'Hostel Area'] },
    { name: 'Residential Area', stops: ['Student Housing', 'Faculty Quarters', 'Sports Complex', 'Food Court'] },
    { name: 'Downtown Express', stops: ['City Center', 'Railway Station', 'Mall', 'Hospital'] },
    { name: 'Sports Complex Route', stops: ['Athletics Center', 'Swimming Pool', 'Cricket Ground', 'Indoor Stadium'] },
    { name: 'Academic Block Circuit', stops: ['Science Block', 'Arts Block', 'Admin Building', 'Auditorium'] },
    { name: 'Medical Center Shuttle', stops: ['Health Center', 'Pharmacy', 'Emergency Ward', 'Dental Clinic'] },
  ];
  
  const drivers = [
    'Rajesh Kumar', 'Amit Sharma', 'Suresh Patel', 'Ramesh Gupta', 
    'Vijay Singh', 'Anil Verma', 'Prakash Rao', 'Manoj Reddy',
    'Sanjay Nair', 'Ravi Kumar', 'Dinesh Shah', 'Krishna Prasad'
  ];

  return routes.map((route, index) => {
    // Distribute buses in a radius around the university
    const angle = (index / routes.length) * 2 * Math.PI;
    const radius = 0.015 + (Math.random() * 0.01); // 1.5-2.5 km radius
    
    return {
      id: `BUS-${String(index + 1).padStart(3, '0')}`,
      route: `Route ${String.fromCharCode(65 + index)} - ${route.name}`,
      driver: drivers[index % drivers.length],
      capacity: 40 + Math.floor(Math.random() * 20), // 40-60 capacity
      occupied: Math.floor(Math.random() * 50),
      location: {
        lat: centerLat + (Math.cos(angle) * radius),
        lng: centerLng + (Math.sin(angle) * radius),
      },
      speed: 20 + Math.floor(Math.random() * 30),
      estimatedArrival: `${3 + Math.floor(Math.random() * 20)} min`,
      nextStop: route.stops[Math.floor(Math.random() * route.stops.length)],
    };
  });
};

// Mock bus data generator (legacy function kept for compatibility)
const generateBusesLegacy = (): Bus[] => [
  {
    id: "BUS-001",
    route: "Route A - Main Campus Loop",
    driver: "John Smith",
    capacity: 50,
    occupied: 32,
    location: { lat: 40.7128, lng: -74.006 },
    speed: 35,
    estimatedArrival: "5 min",
    nextStop: "Engineering Building",
  },
  {
    id: "BUS-002",
    route: "Route B - Residential Area",
    driver: "Sarah Johnson",
    capacity: 45,
    occupied: 28,
    location: { lat: 40.72, lng: -74.01 },
    speed: 40,
    estimatedArrival: "12 min",
    nextStop: "Student Housing",
  },
  {
    id: "BUS-003",
    route: "Route C - Downtown Express",
    driver: "Michael Chen",
    capacity: 55,
    occupied: 45,
    location: { lat: 40.708, lng: -74.002 },
    speed: 30,
    estimatedArrival: "8 min",
    nextStop: "Library",
  },
  {
    id: "BUS-004",
    route: "Route D - Sports Complex",
    driver: "Emily Davis",
    capacity: 40,
    occupied: 15,
    location: { lat: 40.715, lng: -74.015 },
    speed: 25,
    estimatedArrival: "15 min",
    nextStop: "Athletics Center",
  },
];

const calculateDistance = (
  lat1: number,
  lng1: number,
  lat2: number,
  lng2: number,
): number => {
  const R = 6371; // Earth's radius in km
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLng = ((lng2 - lng1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLng / 2) *
      Math.sin(dLng / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
};

const mapContainerStyle = {
  width: "100%",
  height: "600px",
};

const darkMapStyles = [
  {
    elementType: "geometry",
    stylers: [{ color: "#242f3e" }],
  },
  {
    elementType: "labels.text.stroke",
    stylers: [{ color: "#242f3e" }],
  },
  {
    elementType: "labels.text.fill",
    stylers: [{ color: "#746855" }],
  },
  {
    featureType: "administrative.locality",
    elementType: "labels.text.fill",
    stylers: [{ color: "#d59563" }],
  },
  {
    featureType: "poi",
    elementType: "labels.text.fill",
    stylers: [{ color: "#d59563" }],
  },
  {
    featureType: "poi.park",
    elementType: "geometry",
    stylers: [{ color: "#263c3f" }],
  },
  {
    featureType: "poi.park",
    elementType: "labels.text.fill",
    stylers: [{ color: "#6b9a76" }],
  },
  {
    featureType: "road",
    elementType: "geometry",
    stylers: [{ color: "#38414e" }],
  },
  {
    featureType: "road",
    elementType: "geometry.stroke",
    stylers: [{ color: "#212a37" }],
  },
  {
    featureType: "road",
    elementType: "labels.text.fill",
    stylers: [{ color: "#9ca5b3" }],
  },
  {
    featureType: "road.highway",
    elementType: "geometry",
    stylers: [{ color: "#746855" }],
  },
  {
    featureType: "road.highway",
    elementType: "geometry.stroke",
    stylers: [{ color: "#1f2835" }],
  },
  {
    featureType: "road.highway",
    elementType: "labels.text.fill",
    stylers: [{ color: "#f3d19c" }],
  },
  {
    featureType: "transit",
    elementType: "geometry",
    stylers: [{ color: "#2f3948" }],
  },
  {
    featureType: "transit.station",
    elementType: "labels.text.fill",
    stylers: [{ color: "#d59563" }],
  },
  {
    featureType: "water",
    elementType: "geometry",
    stylers: [{ color: "#17263c" }],
  },
  {
    featureType: "water",
    elementType: "labels.text.fill",
    stylers: [{ color: "#515c6d" }],
  },
  {
    featureType: "water",
    elementType: "labels.text.stroke",
    stylers: [{ color: "#17263c" }],
  },
];

export function BusTracker({
  university,
  userLocation,
  onLocationChange,
}: BusTrackerProps) {
  const [buses, setBuses] = useState<Bus[]>(generateBuses(university));
  const [viewMode, setViewMode] = useState<"map" | "list">("map");
  const [selectedBus, setSelectedBus] = useState<Bus | null>(null);
  const [selectedMarkerId, setSelectedMarkerId] = useState<string | null>(null);
  const [pickupLocation, setPickupLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [selectedBusForRoute, setSelectedBusForRoute] = useState<Bus | null>(null);
  const [routeInfo, setRouteInfo] = useState<{
    leg1Distance: string;
    leg1Duration: string;
    leg2Distance: string;
    leg2Duration: string;
  } | null>(null);

  // Get center coordinates for the selected university
  const universityData = INDIAN_UNIVERSITIES[university as keyof typeof INDIAN_UNIVERSITIES];
  const mapCenter = useMemo(() => {
    return universityData 
      ? { lat: universityData.lat, lng: universityData.lng }
      : { lat: 16.4381, lng: 80.5980 };
  }, [universityData]);

  // Generate pickup location when university changes
  useEffect(() => {
    const newPickup = generatePickupLocation(mapCenter.lat, mapCenter.lng);
    setPickupLocation(newPickup);
  }, [mapCenter]);

  // Update buses when university changes
  useEffect(() => {
    setBuses(generateBuses(university));
    setSelectedBus(null);
    setSelectedMarkerId(null);
    setSelectedBusForRoute(null);
  }, [university]);

  // Simulate real-time bus updates
  useEffect(() => {
    const interval = setInterval(() => {
      setBuses((prevBuses) =>
        prevBuses.map((bus) => ({
          ...bus,
          location: {
            lat:
              bus.location.lat + (Math.random() - 0.5) * 0.001,
            lng:
              bus.location.lng + (Math.random() - 0.5) * 0.001,
          },
          occupied: Math.min(
            bus.capacity,
            bus.occupied + Math.floor(Math.random() * 3 - 1),
          ),
        })),
      );
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Pickup Location Card */}
      {pickupLocation && (
        <div className="bg-gradient-to-br from-purple-900/40 to-pink-900/40 backdrop-blur-sm rounded-2xl shadow-xl p-6 border border-purple-400/20 hover:border-purple-400/30 transition-all duration-300">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-pink-500 rounded-xl flex items-center justify-center flex-shrink-0 shadow-lg shadow-purple-500/20">
              <UserCheck className="w-6 h-6 text-white" />
            </div>
            <div className="flex-1">
              <h3 className="text-white mb-2 flex items-center gap-2">
                <span>Waiting for Pickup</span>
                <div className="flex items-center gap-1 text-xs">
                  <div className="w-2 h-2 bg-purple-400 rounded-full animate-pulse-glow"></div>
                  <span className="text-purple-300">Active</span>
                </div>
              </h3>
              <p className="text-sm text-purple-100/70 mb-4">
                You are near {university}. Select a bus below to see the route it will take to pick you up.
              </p>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div className="bg-white/5 rounded-lg p-3">
                  <span className="text-purple-200/60 text-xs">Pickup Location</span>
                  <div className="text-white font-mono text-xs mt-1">
                    {pickupLocation.lat.toFixed(4)}, {pickupLocation.lng.toFixed(4)}
                  </div>
                </div>
                <div className="bg-white/5 rounded-lg p-3">
                  <span className="text-purple-200/60 text-xs">Distance to College</span>
                  <div className="text-white font-medium mt-1">
                    {calculateDistance(
                      pickupLocation.lat,
                      pickupLocation.lng,
                      mapCenter.lat,
                      mapCenter.lng
                    ).toFixed(2)} km
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Bus Selection for Route */}
      {pickupLocation && (
        <div className="bg-slate-900/60 backdrop-blur-xl rounded-2xl shadow-xl p-6 border border-white/10">
          <h3 className="text-white mb-4 flex items-center gap-2">
            <Navigation className="w-5 h-5 text-cyan-400" />
            <span>Select a Bus to View Route</span>
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {buses.map((bus) => {
              const distanceToBus = calculateDistance(
                pickupLocation.lat,
                pickupLocation.lng,
                bus.location.lat,
                bus.location.lng
              );
              const isSelected = selectedBusForRoute?.id === bus.id;
              
              return (
                <button
                  key={bus.id}
                  onClick={() => setSelectedBusForRoute(isSelected ? null : bus)}
                  className={`p-4 rounded-xl border transition-all duration-200 text-left group $\{
                    isSelected
                      ? "bg-cyan-500/10 border-cyan-400/50 shadow-lg shadow-cyan-500/20"
                      : "bg-white/[0.02] border-white/10 hover:border-cyan-400/30 hover:bg-white/[0.05]"
                  }`}
                >
                  <div className="flex items-start justify-between mb-2">
                    <div className="text-sm font-medium text-cyan-400">{bus.id}</div>
                    <div className="text-xs text-blue-200/50">{distanceToBus.toFixed(1)} km</div>
                  </div>
                  <div className="text-xs text-blue-200/50 mb-3 line-clamp-1">{bus.route}</div>
                  <div className="space-y-1.5">
                    <div className="flex items-center gap-2 text-xs">
                      <span className="text-blue-200/50">Driver:</span>
                      <span className="text-white">{bus.driver}</span>
                    </div>
                    <div className="flex items-center gap-2 text-xs">
                      <Clock className="w-3 h-3 text-cyan-400" />
                      <span className="text-white">ETA: {bus.estimatedArrival}</span>
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* User Location Setup */}
      <div className="bg-slate-900/60 backdrop-blur-xl rounded-2xl shadow-xl p-6 border border-white/10 hover:border-cyan-400/30 transition-all duration-300">
        <div className="flex items-start gap-4">
          <div className="w-12 h-12 bg-gradient-to-br from-cyan-500 to-blue-500 rounded-xl flex items-center justify-center flex-shrink-0 shadow-lg shadow-cyan-500/20">
            <MapPin className="w-6 h-6 text-white" />
          </div>
          <div className="flex-1">
            <h3 className="text-white mb-2">
              Your Location
            </h3>
            <p className="text-sm text-blue-200/60 mb-4">
              Set your home or nearest bus stop location to receive proximity notifications
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm text-white/90 mb-2">
                  Latitude
                </label>
                <input
                  type="number"
                  step="0.0001"
                  value={userLocation.lat}
                  onChange={(e) =>
                    onLocationChange({
                      ...userLocation,
                      lat: parseFloat(e.target.value),
                    })
                  }
                  className="w-full px-3 py-2.5 border border-white/10 bg-white/5 text-white rounded-xl focus:ring-2 focus:ring-cyan-400/50 focus:border-cyan-400/50 backdrop-blur-sm hover:bg-white/[0.07] transition-all"
                />
              </div>
              <div>
                <label className="block text-sm text-white/90 mb-2">
                  Longitude
                </label>
                <input
                  type="number"
                  step="0.0001"
                  value={userLocation.lng}
                  onChange={(e) =>
                    onLocationChange({
                      ...userLocation,
                      lng: parseFloat(e.target.value),
                    })
                  }
                  className="w-full px-3 py-2.5 border border-white/10 bg-white/5 text-white rounded-xl focus:ring-2 focus:ring-cyan-400/50 focus:border-cyan-400/50 backdrop-blur-sm hover:bg-white/[0.07] transition-all"
                />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* View Mode Toggle */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-white flex items-center gap-2">
            <span>Active Buses</span>
            <div className="flex items-center gap-1.5 text-sm">
              <div className="w-2 h-2 bg-green-400 rounded-full live-indicator"></div>
              <span className="text-green-400/90 text-xs">Live Updates</span>
            </div>
          </h2>
          <p className="text-sm text-blue-200/50 mt-1">Real-time tracking every 5 seconds</p>
        </div>
        <div className="inline-flex rounded-xl border border-white/10 backdrop-blur-xl bg-slate-900/60 p-1 shadow-lg">
          <button
            onClick={() => setViewMode("map")}
            className={`px-5 py-2.5 rounded-lg text-sm font-medium transition-all duration-200 $\{
              viewMode === "map"
                ? "bg-gradient-to-r from-cyan-500 to-blue-500 text-white shadow-lg shadow-cyan-500/20"
                : "text-blue-200/70 hover:text-white hover:bg-white/5"
            }`}
          >
            Map View
          </button>
          <button
            onClick={() => setViewMode("list")}
            className={`px-5 py-2.5 rounded-lg text-sm font-medium transition-all duration-200 $\{
              viewMode === "list"
                ? "bg-gradient-to-r from-cyan-500 to-blue-500 text-white shadow-lg shadow-cyan-500/20"
                : "text-blue-200/70 hover:text-white hover:bg-white/5"
            }`}
          >
            List View
          </button>
        </div>
      </div>

      {viewMode === "map" ? (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Map */}
          <div className="lg:col-span-2">
            <div className="backdrop-blur-xl bg-gradient-to-br from-white/10 to-white/5 rounded-2xl shadow-2xl overflow-hidden border border-white/20">
              <div className="relative h-[600px]">
                <GoogleMap
                  center={mapCenter}
                  userLocation={userLocation}
                  markers={buses.map((bus) => {
                    const distance = calculateDistance(
                      userLocation.lat,
                      userLocation.lng,
                      bus.location.lat,
                      bus.location.lng
                    );
                    const isNearby = distance <= 1;
                    
                    return {
                      id: bus.id,
                      location: bus.location,
                      label: '🚌',
                      color: isNearby ? '#ef4444' : '#06b6d4',
                    };
                  })}
                  onMarkerClick={(markerId) => {
                    const bus = buses.find((b) => b.id === markerId);
                    if (bus) {
                      setSelectedBus(bus);
                      setSelectedMarkerId(markerId);
                    }
                  }}
                  zoom={14}
                  universityLocation={mapCenter}
                  pickupLocation={pickupLocation || undefined}
                  selectedBusForRoute={selectedBusForRoute ? {
                    id: selectedBusForRoute.id,
                    location: selectedBusForRoute.location
                  } : null}
                  onRouteInfoUpdate={setRouteInfo}
                />
              </div>
            </div>
          </div>

          {/* Bus Details Sidebar */}
          <div className="space-y-4">
            {/* Route Information Panel */}
            {selectedBusForRoute && pickupLocation && (
              <div className="backdrop-blur-xl bg-gradient-to-br from-orange-500/20 to-pink-500/20 rounded-2xl shadow-2xl p-6 border border-orange-400/30 animate-in fade-in duration-300">
                <div className="flex items-center gap-2 mb-4">
                  <Navigation className="w-5 h-5 text-orange-400" />
                  <h3 className="font-semibold text-white">
                    Route for {selectedBusForRoute.id}
                  </h3>
                </div>

                <div className="space-y-4">
                  {/* Trip Summary */}
                  <div className="bg-white/5 rounded-xl p-4 space-y-3">
                    <div className="flex items-start gap-3">
                      <div className="flex-shrink-0 w-8 h-8 bg-orange-500 rounded-full flex items-center justify-center text-white font-bold text-sm">
                        1
                      </div>
                      <div className="flex-1">
                        <div className="text-xs text-orange-300 mb-1">Bus Location → Pickup Point</div>
                        <div className="text-white font-medium">
                          {calculateDistance(
                            selectedBusForRoute.location.lat,
                            selectedBusForRoute.location.lng,
                            pickupLocation.lat,
                            pickupLocation.lng
                          ).toFixed(2)} km
                        </div>
                        <div className="text-xs text-blue-200/60 mt-1">
                          ETA: ~{Math.ceil(calculateDistance(
                            selectedBusForRoute.location.lat,
                            selectedBusForRoute.location.lng,
                            pickupLocation.lat,
                            pickupLocation.lng
                          ) / 0.5)} min
                        </div>
                      </div>
                    </div>

                    <div className="border-l-2 border-orange-400/30 ml-4 pl-4 h-6"></div>

                    <div className="flex items-start gap-3">
                      <div className="flex-shrink-0 w-8 h-8 bg-lime-600 rounded-full flex items-center justify-center text-white font-bold text-sm">
                        2
                      </div>
                      <div className="flex-1">
                        <div className="text-xs text-lime-300 mb-1">Pickup Point → College</div>
                        <div className="text-white font-medium">
                          {calculateDistance(
                            pickupLocation.lat,
                            pickupLocation.lng,
                            mapCenter.lat,
                            mapCenter.lng
                          ).toFixed(2)} km
                        </div>
                        <div className="text-xs text-blue-200/60 mt-1">
                          Duration: ~{Math.ceil(calculateDistance(
                            pickupLocation.lat,
                            pickupLocation.lng,
                            mapCenter.lat,
                            mapCenter.lng
                          ) / 0.5)} min
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Total Trip Info */}
                  <div className="bg-gradient-to-r from-cyan-500/20 to-blue-500/20 rounded-xl p-4 border border-cyan-400/30">
                    <div className="grid grid-cols-2 gap-4 text-center">
                      <div>
                        <div className="text-xs text-cyan-300 mb-1">Total Distance</div>
                        <div className="text-lg font-bold text-white">
                          {(calculateDistance(
                            selectedBusForRoute.location.lat,
                            selectedBusForRoute.location.lng,
                            pickupLocation.lat,
                            pickupLocation.lng
                          ) + calculateDistance(
                            pickupLocation.lat,
                            pickupLocation.lng,
                            mapCenter.lat,
                            mapCenter.lng
                          )).toFixed(2)} km
                        </div>
                      </div>
                      <div>
                        <div className="text-xs text-cyan-300 mb-1">Total Time</div>
                        <div className="text-lg font-bold text-white">
                          ~{Math.ceil((calculateDistance(
                            selectedBusForRoute.location.lat,
                            selectedBusForRoute.location.lng,
                            pickupLocation.lat,
                            pickupLocation.lng
                          ) + calculateDistance(
                            pickupLocation.lat,
                            pickupLocation.lng,
                            mapCenter.lat,
                            mapCenter.lng
                          )) / 0.5)} min
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Driver Info */}
                  <div className="text-sm">
                    <div className="text-blue-200/60 mb-1">Driver</div>
                    <div className="text-white font-medium">{selectedBusForRoute.driver}</div>
                  </div>

                  <button
                    onClick={() => setSelectedBusForRoute(null)}
                    className="w-full py-2 px-4 bg-white/10 hover:bg-white/20 border border-white/20 hover:border-orange-400/50 rounded-xl text-white text-sm font-medium transition-all"
                  >
                    Clear Route
                  </button>
                </div>
              </div>
            )}

            {selectedBus ? (
              <div className="backdrop-blur-xl bg-gradient-to-br from-white/10 to-white/5 rounded-2xl shadow-2xl p-6 border border-white/20 hover:border-cyan-400/50 transition-all duration-300">
                <div className="flex justify-between items-start mb-4">
                  <h3 className="font-semibold text-cyan-300">
                    {selectedBus.id}
                  </h3>
                  <span className="px-3 py-1 bg-gradient-to-r from-green-500 to-emerald-500 text-white text-xs rounded-full shadow-lg shadow-green-500/30">
                    Active
                  </span>
                </div>

                <div className="space-y-4">
                  <div>
                    <div className="text-sm text-blue-200/60 mb-1">
                      Route
                    </div>
                    <div className="font-medium text-white">
                      {selectedBus.route}
                    </div>
                  </div>

                  <div>
                    <div className="text-sm text-blue-200/60 mb-1">
                      Driver
                    </div>
                    <div className="font-medium text-white">
                      {selectedBus.driver}
                    </div>
                  </div>

                  <div>
                    <div className="text-sm text-blue-200/60 mb-2">
                      Occupancy
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="flex-1 bg-white/10 rounded-full h-2 overflow-hidden">
                        <div
                          className="bg-gradient-to-r from-cyan-500 to-blue-500 h-2 rounded-full shadow-lg shadow-cyan-500/50 transition-all duration-300"
                          style={{
                            width: `${(selectedBus.occupied / selectedBus.capacity) * 100}%`,
                          }}
                        />
                      </div>
                      <span className="text-sm font-medium text-cyan-300">
                        {selectedBus.occupied}/
                        {selectedBus.capacity}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 text-sm">
                    <Clock className="w-4 h-4 text-cyan-400" />
                    <span className="text-blue-200/60">ETA:</span>
                    <span className="font-medium text-white">
                      {selectedBus.estimatedArrival}
                    </span>
                  </div>

                  <div className="flex items-center gap-2 text-sm">
                    <Navigation className="w-4 h-4 text-cyan-400" />
                    <span className="text-blue-200/60">
                      Next Stop:
                    </span>
                    <span className="font-medium text-white">
                      {selectedBus.nextStop}
                    </span>
                  </div>

                  <div className="pt-4 border-t border-white/10">
                    <div className="text-sm text-blue-200/60 mb-1">
                      Distance from you
                    </div>
                    <div className="text-lg font-semibold text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-400">
                      {calculateDistance(
                        userLocation.lat,
                        userLocation.lng,
                        selectedBus.location.lat,
                        selectedBus.location.lng,
                      ).toFixed(2)}{" "}
                      km
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              <div className="backdrop-blur-xl bg-gradient-to-br from-white/10 to-white/5 rounded-2xl shadow-2xl p-6 text-center text-blue-200/60 border border-white/20">
                Click on a bus marker to view details
              </div>
            )}

            {/* API Setup Instructions */}
            <div className="backdrop-blur-xl bg-gradient-to-br from-cyan-500/20 to-blue-500/20 border border-cyan-400/30 rounded-2xl p-4 shadow-lg">
              <h4 className="font-medium text-cyan-300 mb-2">
                📍 Real-Time Tracking
              </h4>
              <p className="text-xs text-blue-200/80 mb-3">
                Live tracking for {university}
              </p>
              <div className="text-xs text-blue-200/80 space-y-1">
                <p>✓ {buses.length} buses tracked</p>
                <p>✓ Live location updates</p>
                <p>✓ 1km proximity alerts</p>
                <p>✓ Driver information</p>
              </div>
            </div>
          </div>
        </div>
      ) : (
        /* List View */
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {buses.map((bus) => {
            const distance = calculateDistance(
              userLocation.lat,
              userLocation.lng,
              bus.location.lat,
              bus.location.lng,
            );
            const isNearby = distance <= 1;

            return (
              <div
                key={bus.id}
                className={`backdrop-blur-xl bg-gradient-to-br rounded-2xl shadow-2xl p-6 border-2 transition-all duration-300 hover:scale-[1.02] ${
                  isNearby
                    ? "from-red-500/20 to-pink-500/20 border-red-400/50 shadow-red-500/30"
                    : "from-white/10 to-white/5 border-white/20 hover:border-cyan-400/50"
                }`}
              >
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h3 className="font-semibold text-cyan-300">
                      {bus.id}
                    </h3>
                    <p className="text-sm text-blue-200/60">
                      {bus.route}
                    </p>
                  </div>
                  {isNearby && (
                    <span className="px-3 py-1 bg-gradient-to-r from-red-500 to-pink-500 text-white text-xs rounded-full animate-pulse shadow-lg shadow-red-500/50">
                      Within 1 km
                    </span>
                  )}
                </div>

                <div className="space-y-3">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-blue-200/60">
                      Driver:
                    </span>
                    <span className="font-medium text-white">
                      {bus.driver}
                    </span>
                  </div>

                  <div className="flex items-center justify-between text-sm">
                    <span className="text-blue-200/60">ETA:</span>
                    <span className="font-medium text-white">
                      {bus.estimatedArrival}
                    </span>
                  </div>

                  <div className="flex items-center justify-between text-sm">
                    <span className="text-blue-200/60">
                      Distance:
                    </span>
                    <span
                      className={`font-medium ${isNearby ? "text-red-400" : "text-cyan-300"}`}
                    >
                      {distance.toFixed(2)} km
                    </span>
                  </div>

                  <div>
                    <div className="flex items-center justify-between text-sm mb-2">
                      <span className="text-blue-200/60">
                        Occupancy:
                      </span>
                      <span className="font-medium text-white">
                        {bus.occupied}/{bus.capacity}
                      </span>
                    </div>
                    <div className="bg-white/10 rounded-full h-2 overflow-hidden">
                      <div
                        className="bg-gradient-to-r from-cyan-500 to-blue-500 h-2 rounded-full shadow-lg shadow-cyan-500/50 transition-all duration-300"
                        style={{
                          width: `${(bus.occupied / bus.capacity) * 100}%`,
                        }}
                      />
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}