import { Phone, Mail, MapPin, Calendar, Award, AlertCircle, Star, MessageSquare } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface Driver {
  id: string;
  name: string;
  photo: string;
  busId: string;
  route: string;
  phone: string;
  email: string;
  experience: number;
  rating: number;
  license: string;
  emergencyContact: string;
  shift: string;
  status: 'active' | 'off-duty' | 'break';
  feedbackCount?: number;
}

interface DriverInfoProps {
  university: string;
}

const drivers: Driver[] = [
  {
    id: 'DRV-001',
    name: 'John Smith',
    photo: 'https://images.unsplash.com/photo-1633665503034-78f3628a86e7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBidXMlMjBkcml2ZXIlMjBwb3J0cmFpdHxlbnwxfHx8fDE3Njk4NTUzMDh8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    busId: 'BUS-001',
    route: 'Route A - Main Campus Loop',
    phone: '+1 (555) 123-4567',
    email: 'john.smith@busnav.com',
    experience: 8,
    rating: 4.8,
    license: 'CDL-A-123456',
    emergencyContact: '+1 (555) 123-4568',
    shift: '6:00 AM - 2:00 PM',
    status: 'active',
  },
  {
    id: 'DRV-002',
    name: 'Sarah Johnson',
    photo: 'https://images.unsplash.com/photo-1633665503034-78f3628a86e7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBidXMlMjBkcml2ZXIlMjBwb3J0cmFpdHxlbnwxfHx8fDE3Njk4NTUzMDh8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    busId: 'BUS-002',
    route: 'Route B - Residential Area',
    phone: '+1 (555) 234-5678',
    email: 'sarah.johnson@busnav.com',
    experience: 12,
    rating: 4.9,
    license: 'CDL-A-234567',
    emergencyContact: '+1 (555) 234-5679',
    shift: '7:00 AM - 3:00 PM',
    status: 'active',
  },
  {
    id: 'DRV-003',
    name: 'Michael Chen',
    photo: 'https://images.unsplash.com/photo-1633665503034-78f3628a86e7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBidXMlMjBkcml2ZXIlMjBwb3J0cmFpdHxlbnwxfHx8fDE3Njk4NTUzMDh8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    busId: 'BUS-003',
    route: 'Route C - Downtown Express',
    phone: '+1 (555) 345-6789',
    email: 'michael.chen@busnav.com',
    experience: 5,
    rating: 4.7,
    license: 'CDL-A-345678',
    emergencyContact: '+1 (555) 345-6780',
    shift: '2:00 PM - 10:00 PM',
    status: 'break',
  },
  {
    id: 'DRV-004',
    name: 'Emily Davis',
    photo: 'https://images.unsplash.com/photo-1633665503034-78f3628a86e7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBidXMlMjBkcml2ZXIlMjBwb3J0cmFpdHxlbnwxfHx8fDE3Njk4NTUzMDh8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    busId: 'BUS-004',
    route: 'Route D - Sports Complex',
    phone: '+1 (555) 456-7890',
    email: 'emily.davis@busnav.com',
    experience: 10,
    rating: 4.9,
    license: 'CDL-A-456789',
    emergencyContact: '+1 (555) 456-7891',
    shift: '8:00 AM - 4:00 PM',
    status: 'active',
  },
  {
    id: 'DRV-005',
    name: 'Robert Martinez',
    photo: 'https://images.unsplash.com/photo-1633665503034-78f3628a86e7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBidXMlMjBkcml2ZXIlMjBwb3J0cmFpdHxlbnwxfHx8fDE3Njk4NTUzMDh8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    busId: 'BUS-005',
    route: 'Route E - Medical Center',
    phone: '+1 (555) 567-8901',
    email: 'robert.martinez@busnav.com',
    experience: 15,
    rating: 5.0,
    license: 'CDL-A-567890',
    emergencyContact: '+1 (555) 567-8902',
    shift: '5:00 AM - 1:00 PM',
    status: 'off-duty',
  },
  {
    id: 'DRV-006',
    name: 'Lisa Anderson',
    photo: 'https://images.unsplash.com/photo-1633665503034-78f3628a86e7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBidXMlMjBkcml2ZXIlMjBwb3J0cmFpdHxlbnwxfHx8fDE3Njk4NTUzMDh8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    busId: 'BUS-006',
    route: 'Route F - Library Circle',
    phone: '+1 (555) 678-9012',
    email: 'lisa.anderson@busnav.com',
    experience: 7,
    rating: 4.8,
    license: 'CDL-A-678901',
    emergencyContact: '+1 (555) 678-9013',
    shift: '9:00 AM - 5:00 PM',
    status: 'active',
  },
];

export function DriverInfo({ university }: DriverInfoProps) {
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active':
        return 'bg-green-500/10 text-green-400 border-green-400/30';
      case 'break':
        return 'bg-yellow-500/10 text-yellow-400 border-yellow-400/30';
      case 'off-duty':
        return 'bg-slate-500/10 text-slate-400 border-slate-400/30';
      default:
        return 'bg-slate-500/10 text-slate-400 border-slate-400/30';
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'active':
        return 'On Duty';
      case 'break':
        return 'On Break';
      case 'off-duty':
        return 'Off Duty';
      default:
        return status;
    }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header Info */}
      <div className="bg-slate-900/60 backdrop-blur-xl rounded-2xl shadow-xl p-6 border border-white/10">
        <div className="flex items-start gap-4">
          <div className="w-12 h-12 bg-gradient-to-br from-cyan-500 to-blue-500 rounded-xl flex items-center justify-center flex-shrink-0 shadow-lg shadow-cyan-500/20">
            <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
            </svg>
          </div>
          <div className="flex-1">
            <h2 className="text-white mb-2">Driver Directory</h2>
            <p className="text-sm text-blue-200/60">
              Contact information for all drivers at {university}. For emergencies, call campus security at <strong className="text-cyan-400">(555) 911-0000</strong>.
            </p>
          </div>
        </div>
      </div>

      {/* Emergency Notice */}
      <div className="bg-red-900/30 backdrop-blur-sm border border-red-400/20 rounded-2xl p-4 flex items-start gap-3 shadow-lg">
        <AlertCircle className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" />
        <div>
          <h3 className="font-medium text-red-400 mb-1">Emergency Contact</h3>
          <p className="text-sm text-red-300/70">
            In case of emergency, contact campus security immediately at <strong className="text-red-300">(555) 911-0000</strong> or use the emergency contact listed for each driver.
          </p>
        </div>
      </div>

      {/* Drivers Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {drivers.map((driver, index) => (
          <div 
            key={driver.id} 
            className="bg-slate-900/60 backdrop-blur-xl rounded-2xl shadow-xl overflow-hidden border border-white/10 hover:border-cyan-400/30 transition-all duration-300 group animate-slide-in"
            style={{ animationDelay: `${index * 50}ms` }}
          >
            <div className="p-6">
              <div className="flex items-start gap-4 mb-6">
                <div className="relative">
                  <div className="absolute inset-0 bg-gradient-to-br from-cyan-500/30 to-blue-500/30 blur-lg rounded-full opacity-0 group-hover:opacity-100 transition-opacity"></div>
                  <ImageWithFallback
                    src={driver.photo}
                    alt={driver.name}
                    className="w-20 h-20 rounded-full object-cover border-2 border-white/20 relative z-10"
                  />
                  {driver.status === 'active' && (
                    <div className="absolute bottom-0 right-0 w-5 h-5 bg-green-400 rounded-full border-2 border-slate-900 live-indicator z-20"></div>
                  )}
                </div>
                <div className="flex-1">
                  <div className="flex items-start justify-between mb-2">
                    <div>
                      <h3 className="font-medium text-white">{driver.name}</h3>
                      <p className="text-xs text-blue-200/50">{driver.id}</p>
                    </div>
                    <span className={`px-3 py-1 rounded-full text-xs font-medium border ${getStatusColor(driver.status)}`}>
                      {getStatusLabel(driver.status)}
                    </span>
                  </div>
                  
                  <div className="flex items-center gap-1 mb-2">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <Star
                        key={i}
                        className={`w-3.5 h-3.5 ${i < Math.floor(driver.rating) ? 'text-yellow-400 fill-yellow-400' : 'text-slate-600'}`}
                      />
                    ))}
                    <span className="text-xs text-blue-200/50 ml-1">{driver.rating}</span>
                  </div>

                  <div className="flex items-center gap-2 text-xs text-blue-200/60">
                    <Award className="w-3.5 h-3.5 text-cyan-400" />
                    <span>{driver.experience} years experience</span>
                  </div>
                </div>
              </div>

              {/* Bus Assignment */}
              <div className="bg-cyan-500/5 border border-cyan-400/20 rounded-xl p-4 mb-4">
                <div className="flex items-center gap-2 mb-2">
                  <svg className="w-5 h-5 text-cyan-400" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M13 16V6a1 1 0 00-1-1H4a1 1 0 00-1 1v10a1 1 0 001 1h1m8-1a1 1 0 01-1 1H9m4-1V8a1 1 0 011-1h2.586a1 1 0 01.707.293l3.414 3.414a1 1 0 01.293.707V16a1 1 0 01-1 1h-1m-6-1a1 1 0 001 1h1M5 17a2 2 0 104 0m-4 0a2 2 0 114 0m6 0a2 2 0 104 0m-4 0a2 2 0 114 0" />
                  </svg>
                  <span className="font-medium text-cyan-400 text-sm">{driver.busId}</span>
                </div>
                <p className="text-sm text-blue-200/70 line-clamp-1">{driver.route}</p>
              </div>

              {/* Contact Information */}
              <div className="space-y-3">
                <div className="flex items-center gap-3 text-sm">
                  <Phone className="w-4 h-4 text-cyan-400 flex-shrink-0" />
                  <div className="min-w-0 flex-1">
                    <div className="text-blue-200/50 text-xs mb-0.5">Phone</div>
                    <a href={`tel:${driver.phone}`} className="text-white hover:text-cyan-400 transition-colors text-sm">
                      {driver.phone}
                    </a>
                  </div>
                </div>

                <div className="flex items-center gap-3 text-sm">
                  <Mail className="w-4 h-4 text-cyan-400 flex-shrink-0" />
                  <div className="min-w-0 flex-1">
                    <div className="text-blue-200/50 text-xs mb-0.5">Email</div>
                    <a href={`mailto:${driver.email}`} className="text-white hover:text-cyan-400 break-all transition-colors text-sm">
                      {driver.email}
                    </a>
                  </div>
                </div>

                <div className="flex items-center gap-3 text-sm">
                  <Calendar className="w-4 h-4 text-cyan-400 flex-shrink-0" />
                  <div className="min-w-0 flex-1">
                    <div className="text-blue-200/50 text-xs mb-0.5">Shift</div>
                    <div className="text-white text-sm">{driver.shift}</div>
                  </div>
                </div>

                <div className="pt-3 border-t border-white/10">
                  <div className="text-xs text-blue-200/50 mb-1.5">Emergency Contact</div>
                  <a href={`tel:${driver.emergencyContact}`} className="text-sm text-red-400 hover:text-red-300 font-medium transition-colors flex items-center gap-2">
                    <AlertCircle className="w-3.5 h-3.5" />
                    {driver.emergencyContact}
                  </a>
                </div>

                <div className="pt-2">
                  <div className="text-xs text-blue-200/50 mb-1.5">License Number</div>
                  <div className="text-sm text-cyan-400 font-mono">{driver.license}</div>
                </div>
              </div>
            </div>

            {/* Feedback Indicator */}
            {driver.feedbackCount && (
              <div className="px-6 py-3 bg-white/5 border-t border-white/10 flex items-center justify-between text-sm">
                <span className="text-blue-200/60 flex items-center gap-2">
                  <MessageSquare className="w-4 h-4 text-cyan-400" />
                  Feedback
                </span>
                <span className="text-white font-medium">{driver.feedbackCount} reviews</span>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}