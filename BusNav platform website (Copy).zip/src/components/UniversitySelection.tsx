import { Search, MapPin, Bus, ArrowRight } from 'lucide-react';
import { motion } from 'framer-motion';
import logo from 'figma:asset/c318be13d83ec253d11a3c8f71f277389266d69b.png';
import { useState } from 'react';

const universities = [
  { id: 1, name: 'SRM AP University', location: 'Amaravati, Andhra Pradesh', buses: 6 },
  { id: 2, name: 'IIT Madras', location: 'Chennai, Tamil Nadu', buses: 6 },
  { id: 3, name: 'IIT Delhi', location: 'New Delhi', buses: 6 },
  { id: 4, name: 'IIT Bombay', location: 'Mumbai, Maharashtra', buses: 6 },
  { id: 5, name: 'BITS Pilani', location: 'Pilani, Rajasthan', buses: 6 },
  { id: 6, name: 'VIT Vellore', location: 'Vellore, Tamil Nadu', buses: 6 },
  { id: 7, name: 'NIT Trichy', location: 'Tiruchirappalli, Tamil Nadu', buses: 6 },
  { id: 8, name: 'IIIT Hyderabad', location: 'Hyderabad, Telangana', buses: 6 },
  { id: 9, name: 'IIT Kanpur', location: 'Kanpur, Uttar Pradesh', buses: 6 },
  { id: 10, name: 'IIT Kharagpur', location: 'Kharagpur, West Bengal', buses: 6 },
  { id: 11, name: 'Anna University', location: 'Chennai, Tamil Nadu', buses: 6 },
  { id: 12, name: 'Jadavpur University', location: 'Kolkata, West Bengal', buses: 6 },
  { id: 13, name: 'Manipal Institute of Technology', location: 'Manipal, Karnataka', buses: 6 },
  { id: 14, name: 'Delhi University', location: 'New Delhi', buses: 6 },
  { id: 15, name: 'Amity University', location: 'Noida, Uttar Pradesh', buses: 6 },
];

interface UniversitySelectionProps {
  onSelect: (university: string) => void;
}

export function UniversitySelection({ onSelect }: UniversitySelectionProps) {
  const [searchQuery, setSearchQuery] = useState('');

  const filteredUniversities = universities.filter(uni =>
    uni.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    uni.location.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-blue-950 to-slate-900 flex items-center justify-center p-4 relative overflow-hidden">
      {/* Animated background elements */}
      <div className="absolute inset-0 overflow-hidden">
        <motion.div 
          className="absolute top-1/3 left-1/3 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl"
          animate={{ 
            scale: [1, 1.2, 1],
            opacity: [0.3, 0.6, 0.3]
          }}
          transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
        />
        <motion.div 
          className="absolute bottom-1/3 right-1/3 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl"
          animate={{ 
            scale: [1.2, 1, 1.2],
            opacity: [0.6, 0.3, 0.6]
          }}
          transition={{ duration: 8, repeat: Infinity, ease: "easeInOut", delay: 1.5 }}
        />
      </div>

      <motion.div 
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-4xl relative z-10"
      >
        <div className="text-center mb-10">
          <motion.div 
            initial={{ scale: 0, rotate: -180 }}
            animate={{ scale: 1, rotate: 0 }}
            transition={{ type: "spring", stiffness: 200, damping: 15 }}
            className="inline-flex items-center justify-center mb-6 relative"
          >
            <div className="absolute inset-0 bg-gradient-to-r from-blue-500/20 to-cyan-500/20 blur-2xl rounded-full"></div>
            <img src={logo} alt="BusNav Logo" className="w-44 h-44 object-contain relative z-10" />
          </motion.div>
          <motion.h1 
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.2 }}
            className="text-4xl font-semibold text-white mb-3"
          >
            Choose Your <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-400">University</span>
          </motion.h1>
          <motion.p 
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.3 }}
            className="text-blue-200/60"
          >
            Real-time bus tracking for 15 major universities across India
          </motion.p>
        </div>

        <motion.div 
          initial={{ y: 40, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.4 }}
          className="bg-slate-900/60 backdrop-blur-xl rounded-2xl shadow-2xl p-6 sm:p-8 border border-white/10"
        >
          <div className="mb-6">
            <label htmlFor="search" className="block text-sm text-white/90 mb-3">
              Search universities
            </label>
            <div className="relative group">
              <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                <Search className="h-5 w-5 text-blue-400/50 group-focus-within:text-cyan-400/70 transition-colors" />
              </div>
              <input
                type="text"
                id="search"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="block w-full pl-11 pr-4 py-3.5 border border-white/10 bg-white/5 text-white rounded-xl focus:ring-2 focus:ring-cyan-400/50 focus:border-cyan-400/50 placeholder-blue-300/30 backdrop-blur-sm hover:bg-white/[0.07] transition-all"
                placeholder="Search by name or location..."
              />
            </div>
          </div>

          <div className="space-y-3 max-h-[480px] overflow-y-auto pr-2">
            {filteredUniversities.length > 0 ? (
              filteredUniversities.map((uni, index) => (
                <motion.button
                  key={uni.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.05 }}
                  whileHover={{ scale: 1.02, x: 4 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => onSelect(uni.name)}
                  className="w-full text-left p-5 rounded-xl border border-white/10 hover:border-cyan-400/30 bg-white/[0.02] hover:bg-white/[0.05] transition-all duration-200 group backdrop-blur-sm"
                >
                  <div className="flex justify-between items-center gap-4">
                    <div className="flex-1 min-w-0">
                      <h3 className="font-medium text-white group-hover:text-cyan-300 mb-1.5 transition-colors truncate">
                        {uni.name}
                      </h3>
                      <div className="flex items-center gap-2 text-sm text-blue-200/50">
                        <MapPin className="h-3.5 w-3.5 flex-shrink-0" />
                        <span className="truncate">{uni.location}</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-3 flex-shrink-0">
                      <div className="text-right">
                        <div className="flex items-center gap-1.5 text-cyan-400 mb-1">
                          <Bus className="h-4 w-4" />
                          <span className="text-sm font-medium">{uni.buses}</span>
                        </div>
                        <div className="flex items-center gap-1.5">
                          <div className="w-2 h-2 bg-green-400 rounded-full live-indicator"></div>
                          <span className="text-xs text-green-400/90">Live</span>
                        </div>
                      </div>
                      <ArrowRight className="h-5 w-5 text-blue-300/30 group-hover:text-cyan-400 group-hover:translate-x-1 transition-all" />
                    </div>
                  </div>
                </motion.button>
              ))
            ) : (
              <motion.div 
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="text-center py-16 px-4"
              >
                <motion.div 
                  animate={{ y: [0, -10, 0] }}
                  transition={{ duration: 2, repeat: Infinity }}
                  className="w-16 h-16 mx-auto mb-4 rounded-full bg-blue-500/10 flex items-center justify-center"
                >
                  <Search className="h-8 w-8 text-blue-400/50" />
                </motion.div>
                <p className="text-blue-200/60 mb-2">No universities found</p>
                <p className="text-sm text-blue-200/40">Try searching with a different name or location</p>
              </motion.div>
            )}
          </div>

          {filteredUniversities.length > 0 && (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.5 }}
              className="mt-6 pt-5 border-t border-white/10"
            >
              <p className="text-xs text-center text-blue-200/40">
                {filteredUniversities.length} {filteredUniversities.length === 1 ? 'university' : 'universities'} available
              </p>
            </motion.div>
          )}
        </motion.div>
      </motion.div>
    </div>
  );
}