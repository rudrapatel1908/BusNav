import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Mail, Lock, User, Users, Phone, CreditCard, AlertCircle, Check } from 'lucide-react';
import * as API from '../utils/api';
import logo from 'figma:asset/c318be13d83ec253d11a3c8f71f277389266d69b.png';
import backgroundImage from 'figma:asset/74483e80f15c7a4c4af9ba7af447a0883bca6742.png';

interface LoginProps {
  onLogin: (userType: 'student' | 'parent', email: string) => void;
}

export function Login({ onLogin }: LoginProps) {
  const [isSignUp, setIsSignUp] = useState(false);
  const [userType, setUserType] = useState<'student' | 'parent'>('student');
  const [name, setName] = useState('');
  const [rollNumber, setRollNumber] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [emergencyPhone, setEmergencyPhone] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [rememberMe, setRememberMe] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');
    setLoading(true);

    try {
      if (isSignUp) {
        // Validate all signup fields
        if (!name.trim()) {
          setError('Please enter your name');
          setLoading(false);
          return;
        }
        
        if (!rollNumber.trim()) {
          setError('Please enter your roll number');
          setLoading(false);
          return;
        }
        
        if (!phoneNumber.trim()) {
          setError('Please enter your phone number');
          setLoading(false);
          return;
        }
        
        if (!emergencyPhone.trim()) {
          setError('Please enter an emergency contact number');
          setLoading(false);
          return;
        }
        
        if (password !== confirmPassword) {
          setError('Passwords do not match');
          setLoading(false);
          return;
        }
        
        if (password.length < 6) {
          setError('Password must be at least 6 characters long');
          setLoading(false);
          return;
        }
        
        // Create account with all the details
        await API.signUp(email, password, name, userType, rollNumber, phoneNumber, emergencyPhone);
        setSuccess('Account created successfully! Please sign in with your college email and password.');
        
        // Clear form and switch to login mode
        setTimeout(() => {
          setIsSignUp(false);
          setSuccess('');
          setName('');
          setRollNumber('');
          setPhoneNumber('');
          setEmergencyPhone('');
          setPassword('');
          setConfirmPassword('');
        }, 2000);
      } else {
        // Sign In - Only works with registered credentials
        const { user } = await API.signIn(email, password);
        
        // Get user role from the metadata stored during signup
        const registeredRole = user?.user_metadata?.role || userType;
        
        // Login successful - use the role from their account
        onLogin(registeredRole, user.email || email);
      }
    } catch (err: any) {
      // Show specific error messages
      if (err.message.includes('Invalid login credentials')) {
        setError('Invalid email or password. Please check your credentials and try again.');
      } else if (err.message.includes('Email not confirmed')) {
        setError('Please verify your email address before logging in.');
      } else {
        setError(err.message || 'Authentication failed');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleSocialLogin = (provider: 'google' | 'facebook') => {
    // Social login is disabled - only email/password authentication is allowed
    setError('Social login is disabled. Please sign up or sign in with email and password.');
  };

  return (
    <div className="min-h-screen relative overflow-hidden">
      {/* Background Image with Neutral Dark Overlay */}
      <div className="absolute inset-0">
        <img 
          src={backgroundImage} 
          alt="City Bus Background" 
          className="w-full h-full object-cover"
        />
        {/* Neutral dark overlay - no blue tones */}
        <div className="absolute inset-0 bg-gradient-to-br from-black/85 via-slate-950/90 to-black/85"></div>
      </div>

      {/* Animated Floating Orbs - Cyan/Blue to contrast with neutral background */}
      <div className="absolute inset-0">
        <motion.div
          animate={{
            scale: [1, 1.2, 1],
            opacity: [0.12, 0.25, 0.12],
          }}
          transition={{
            duration: 8,
            repeat: Infinity,
            ease: "easeInOut"
          }}
          className="absolute top-20 left-20 w-96 h-96 bg-cyan-500/40 rounded-full blur-3xl"
        />
        <motion.div
          animate={{
            scale: [1.2, 1, 1.2],
            opacity: [0.15, 0.3, 0.15],
          }}
          transition={{
            duration: 10,
            repeat: Infinity,
            ease: "easeInOut"
          }}
          className="absolute bottom-20 right-20 w-96 h-96 bg-blue-500/40 rounded-full blur-3xl"
        />
        <motion.div
          animate={{
            scale: [1, 1.3, 1],
            opacity: [0.08, 0.2, 0.08],
          }}
          transition={{
            duration: 12,
            repeat: Infinity,
            ease: "easeInOut"
          }}
          className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-cyan-500/35 rounded-full blur-3xl"
        />
      </div>

      <div className="relative min-h-screen flex items-center justify-center p-4">
        <div className="w-full max-w-md">
          {/* Logo and Title */}
          <div className="text-center mb-10">
            <motion.div 
              initial={{ scale: 0.5, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ delay: 0.2, type: "spring", stiffness: 200 }}
              className="inline-flex items-center justify-center mb-6 relative"
            >
              {/* Outer glow effect */}
              <div className="absolute inset-0 bg-gradient-to-r from-blue-500/40 to-cyan-500/40 blur-3xl rounded-full"></div>
              
              {/* Horizontal rectangular glass container with curves */}
              <div className="relative w-80 h-48 rounded-3xl bg-white/[0.12] backdrop-blur-3xl border-2 border-white/30 shadow-[0_8px_32px_0_rgba(0,0,0,0.4)] overflow-hidden">
                {/* Inner shine effect */}
                <div className="absolute inset-0 bg-gradient-to-br from-white/25 via-transparent to-transparent"></div>
                
                {/* Logo */}
                <div className="absolute inset-0 flex items-center justify-center p-4">
                  <img src={logo} alt="BusNav Logo" className="w-full h-full object-contain relative z-10 drop-shadow-2xl" />
                </div>
              </div>
            </motion.div>
            
            <motion.h1 
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.3 }}
              className="text-4xl font-semibold text-white mb-2 drop-shadow-lg"
            >
              Welcome to <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-400">BusNav</span>
            </motion.h1>
            <motion.p 
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.4 }}
              className="text-blue-200/80 drop-shadow-md"
            >
              Real-time bus tracking made simple
            </motion.p>
          </div>

          {/* Liquid Glass Login Card - Enhanced */}
          <motion.div 
            initial={{ y: 40, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.5 }}
            className="relative"
          >
            {/* Stronger outer glow */}
            <div className="absolute -inset-2 bg-gradient-to-r from-cyan-500/30 to-blue-500/30 rounded-3xl blur-2xl"></div>
            
            {/* Main glass container with enhanced prominence */}
            <div className="relative bg-white/[0.12] backdrop-blur-3xl rounded-3xl shadow-[0_8px_32px_0_rgba(0,0,0,0.5)] border-2 border-white/30 overflow-hidden">
              {/* Stronger inner shine effect */}
              <div className="absolute inset-0 bg-gradient-to-br from-white/15 via-transparent to-transparent pointer-events-none"></div>
              
              {/* Content */}
              <div className="relative p-8">
                {/* User Type Selection */}
                <div className="grid grid-cols-2 gap-3 mb-8">
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    type="button"
                    onClick={() => setUserType('student')}
                    className={`relative p-5 rounded-2xl transition-all duration-300 group overflow-hidden ${
                      userType === 'student'
                        ? 'shadow-lg'
                        : ''
                    }`}
                  >
                    {/* Glass background */}
                    <div className={`absolute inset-0 transition-all duration-300 ${
                      userType === 'student'
                        ? 'bg-gradient-to-br from-cyan-400/30 to-blue-400/30 backdrop-blur-xl'
                        : 'bg-white/[0.05] backdrop-blur-md group-hover:bg-white/[0.08]'
                    }`}></div>
                    {/* Border */}
                    <div className={`absolute inset-0 rounded-2xl transition-all duration-300 ${
                      userType === 'student'
                        ? 'border-2 border-cyan-400/50'
                        : 'border border-white/20 group-hover:border-white/30'
                    }`}></div>
                    {/* Inner glow */}
                    {userType === 'student' && (
                      <div className="absolute inset-0 bg-gradient-to-br from-cyan-400/20 to-transparent blur-xl"></div>
                    )}
                    
                    <User className={`relative w-7 h-7 mx-auto mb-2 transition-all duration-200 ${
                      userType === 'student' ? 'text-cyan-300 drop-shadow-[0_0_8px_rgba(34,211,238,0.5)]' : 'text-blue-300/50 group-hover:text-blue-300/70'
                    }`} />
                    <div className={`relative text-sm transition-colors duration-200 ${
                      userType === 'student' ? 'text-cyan-200 font-medium' : 'text-blue-200/50 group-hover:text-blue-200/70'
                    }`}>
                      Student
                    </div>
                  </motion.button>

                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    type="button"
                    onClick={() => setUserType('parent')}
                    className={`relative p-5 rounded-2xl transition-all duration-300 group overflow-hidden ${
                      userType === 'parent'
                        ? 'shadow-lg'
                        : ''
                    }`}
                  >
                    {/* Glass background */}
                    <div className={`absolute inset-0 transition-all duration-300 ${
                      userType === 'parent'
                        ? 'bg-gradient-to-br from-cyan-400/30 to-blue-400/30 backdrop-blur-xl'
                        : 'bg-white/[0.05] backdrop-blur-md group-hover:bg-white/[0.08]'
                    }`}></div>
                    {/* Border */}
                    <div className={`absolute inset-0 rounded-2xl transition-all duration-300 ${
                      userType === 'parent'
                        ? 'border-2 border-cyan-400/50'
                        : 'border border-white/20 group-hover:border-white/30'
                    }`}></div>
                    {/* Inner glow */}
                    {userType === 'parent' && (
                      <div className="absolute inset-0 bg-gradient-to-br from-cyan-400/20 to-transparent blur-xl"></div>
                    )}
                    
                    <Users className={`relative w-7 h-7 mx-auto mb-2 transition-all duration-200 ${
                      userType === 'parent' ? 'text-cyan-300 drop-shadow-[0_0_8px_rgba(34,211,238,0.5)]' : 'text-blue-300/50 group-hover:text-blue-300/70'
                    }`} />
                    <div className={`relative text-sm transition-colors duration-200 ${
                      userType === 'parent' ? 'text-cyan-200 font-medium' : 'text-blue-200/50 group-hover:text-blue-200/70'
                    }`}>
                      Parent
                    </div>
                  </motion.button>
                </div>

                <form onSubmit={handleSubmit} className="space-y-5">
                  {/* Name Input (only for signup) */}
                  {isSignUp && (
                    <div className="animate-slide-in">
                      <label htmlFor="name" className="block text-sm text-white/90 mb-2">
                        Full Name
                      </label>
                      <div className="relative group">
                        {/* Glass effect wrapper */}
                        <div className="absolute inset-0 bg-white/[0.03] backdrop-blur-md rounded-xl border border-white/10 group-hover:border-white/20 group-focus-within:border-cyan-400/50 transition-all"></div>
                        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none z-10">
                          <User className="h-5 w-5 text-blue-400/50 group-focus-within:text-cyan-400/70 transition-colors" />
                        </div>
                        <input
                          type="text"
                          id="name"
                          value={name}
                          onChange={(e) => setName(e.target.value)}
                          className="relative block w-full pl-10 pr-4 py-3 bg-transparent text-white rounded-xl focus:ring-2 focus:ring-cyan-400/50 placeholder-blue-300/30 transition-all border-0 focus:outline-none"
                          placeholder="Enter your full name"
                          required={isSignUp}
                        />
                      </div>
                    </div>
                  )}

                  {/* College Roll Number (only for signup) */}
                  {isSignUp && (
                    <div className="animate-slide-in">
                      <label htmlFor="rollNumber" className="block text-sm text-white/90 mb-2">
                        College Roll Number
                      </label>
                      <div className="relative group">
                        <div className="absolute inset-0 bg-white/[0.03] backdrop-blur-md rounded-xl border border-white/10 group-hover:border-white/20 group-focus-within:border-cyan-400/50 transition-all"></div>
                        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none z-10">
                          <CreditCard className="h-5 w-5 text-blue-400/50 group-focus-within:text-cyan-400/70 transition-colors" />
                        </div>
                        <input
                          type="text"
                          id="rollNumber"
                          value={rollNumber}
                          onChange={(e) => setRollNumber(e.target.value)}
                          className="relative block w-full pl-10 pr-4 py-3 bg-transparent text-white rounded-xl focus:ring-2 focus:ring-cyan-400/50 placeholder-blue-300/30 transition-all border-0 focus:outline-none"
                          placeholder="Enter your roll number"
                          required={isSignUp}
                        />
                      </div>
                    </div>
                  )}

                  {/* Phone Number (only for signup) */}
                  {isSignUp && (
                    <div className="animate-slide-in">
                      <label htmlFor="phoneNumber" className="block text-sm text-white/90 mb-2">
                        Phone Number
                      </label>
                      <div className="relative group">
                        <div className="absolute inset-0 bg-white/[0.03] backdrop-blur-md rounded-xl border border-white/10 group-hover:border-white/20 group-focus-within:border-cyan-400/50 transition-all"></div>
                        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none z-10">
                          <Phone className="h-5 w-5 text-blue-400/50 group-focus-within:text-cyan-400/70 transition-colors" />
                        </div>
                        <input
                          type="tel"
                          id="phoneNumber"
                          value={phoneNumber}
                          onChange={(e) => setPhoneNumber(e.target.value)}
                          className="relative block w-full pl-10 pr-4 py-3 bg-transparent text-white rounded-xl focus:ring-2 focus:ring-cyan-400/50 placeholder-blue-300/30 transition-all border-0 focus:outline-none"
                          placeholder="Enter your phone number"
                          required={isSignUp}
                        />
                      </div>
                    </div>
                  )}

                  {/* Emergency Phone Number (only for signup) */}
                  {isSignUp && (
                    <div className="animate-slide-in">
                      <label htmlFor="emergencyPhone" className="block text-sm text-white/90 mb-2">
                        Emergency Phone Number
                      </label>
                      <div className="relative group">
                        <div className="absolute inset-0 bg-white/[0.03] backdrop-blur-md rounded-xl border border-white/10 group-hover:border-white/20 group-focus-within:border-cyan-400/50 transition-all"></div>
                        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none z-10">
                          <AlertCircle className="h-5 w-5 text-blue-400/50 group-focus-within:text-cyan-400/70 transition-colors" />
                        </div>
                        <input
                          type="tel"
                          id="emergencyPhone"
                          value={emergencyPhone}
                          onChange={(e) => setEmergencyPhone(e.target.value)}
                          className="relative block w-full pl-10 pr-4 py-3 bg-transparent text-white rounded-xl focus:ring-2 focus:ring-cyan-400/50 placeholder-blue-300/30 transition-all border-0 focus:outline-none"
                          placeholder="Enter emergency contact number"
                          required={isSignUp}
                        />
                      </div>
                    </div>
                  )}

                  {/* Email Input */}
                  <div>
                    <label htmlFor="email" className="block text-sm text-white/90 mb-2">
                      {isSignUp ? 'College Email ID' : 'Email Address'}
                    </label>
                    <div className="relative group">
                      <div className="absolute inset-0 bg-white/[0.03] backdrop-blur-md rounded-xl border border-white/10 group-hover:border-white/20 group-focus-within:border-cyan-400/50 transition-all"></div>
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none z-10">
                        <Mail className="h-5 w-5 text-blue-400/50 group-focus-within:text-cyan-400/70 transition-colors" />
                      </div>
                      <input
                        type="email"
                        id="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        className="relative block w-full pl-10 pr-4 py-3 bg-transparent text-white rounded-xl focus:ring-2 focus:ring-cyan-400/50 placeholder-blue-300/30 transition-all border-0 focus:outline-none"
                        placeholder={isSignUp ? 'your.name@university.edu' : (userType === 'student' ? 'student@university.edu' : 'parent@email.com')}
                        required
                      />
                    </div>
                  </div>

                  {/* Password Input */}
                  <div>
                    <label htmlFor="password" className="block text-sm text-white/90 mb-2">
                      Password
                    </label>
                    <div className="relative group">
                      <div className="absolute inset-0 bg-white/[0.03] backdrop-blur-md rounded-xl border border-white/10 group-hover:border-white/20 group-focus-within:border-cyan-400/50 transition-all"></div>
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none z-10">
                        <Lock className="h-5 w-5 text-blue-400/50 group-focus-within:text-cyan-400/70 transition-colors" />
                      </div>
                      <input
                        type="password"
                        id="password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        className="relative block w-full pl-10 pr-4 py-3 bg-transparent text-white rounded-xl focus:ring-2 focus:ring-cyan-400/50 placeholder-blue-300/30 transition-all border-0 focus:outline-none"
                        placeholder="Enter your password"
                        required
                      />
                    </div>
                  </div>

                  {/* Confirm Password Input (only for signup) */}
                  {isSignUp && (
                    <div className="animate-slide-in">
                      <label htmlFor="confirmPassword" className="block text-sm text-white/90 mb-2">
                        Confirm Password
                      </label>
                      <div className="relative group">
                        <div className="absolute inset-0 bg-white/[0.03] backdrop-blur-md rounded-xl border border-white/10 group-hover:border-white/20 group-focus-within:border-cyan-400/50 transition-all"></div>
                        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none z-10">
                          <Lock className="h-5 w-5 text-blue-400/50 group-focus-within:text-cyan-400/70 transition-colors" />
                        </div>
                        <input
                          type="password"
                          id="confirmPassword"
                          value={confirmPassword}
                          onChange={(e) => setConfirmPassword(e.target.value)}
                          className="relative block w-full pl-10 pr-4 py-3 bg-transparent text-white rounded-xl focus:ring-2 focus:ring-cyan-400/50 placeholder-blue-300/30 transition-all border-0 focus:outline-none"
                          placeholder="Confirm your password"
                          required={isSignUp}
                        />
                      </div>
                    </div>
                  )}

                  {/* Remember Me & Forgot Password */}
                  {!isSignUp && (
                    <div className="flex items-center justify-between pt-1">
                      <label className="flex items-center group cursor-pointer">
                        <input
                          type="checkbox"
                          checked={rememberMe}
                          onChange={(e) => setRememberMe(e.target.checked)}
                          className="rounded border-white/20 bg-white/5 text-cyan-500 focus:ring-cyan-500 focus:ring-offset-0 cursor-pointer"
                        />
                        <span className="ml-2 text-sm text-blue-200/70 group-hover:text-blue-200/90 transition-colors">Remember me</span>
                      </label>
                      <button type="button" className="text-sm text-cyan-400 hover:text-cyan-300 transition-colors">
                        Forgot password?
                      </button>
                    </div>
                  )}

                  {/* Error Message */}
                  {error && (
                    <div className="bg-red-500/10 border border-red-500/20 rounded-xl p-3.5 text-red-300 text-sm animate-slide-in flex items-start gap-2">
                      <AlertCircle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                      <span>{error}</span>
                    </div>
                  )}

                  {/* Success Message */}
                  {success && (
                    <div className="bg-green-500/10 border border-green-500/20 rounded-xl p-3.5 text-green-300 text-sm animate-slide-in flex items-start gap-2">
                      <Check className="h-4 w-4 mt-0.5 flex-shrink-0" />
                      <span>{success}</span>
                    </div>
                  )}

                  {/* Login Button */}
                  <button
                    type="submit"
                    disabled={loading}
                    className="w-full bg-gradient-to-r from-cyan-500 to-blue-500 text-white py-3.5 px-6 rounded-xl font-medium hover:from-cyan-400 hover:to-blue-400 active:scale-[0.98] transition-all duration-200 shadow-lg shadow-cyan-500/20 hover:shadow-cyan-500/30 disabled:opacity-50 disabled:cursor-not-allowed disabled:active:scale-100 mt-6"
                  >
                    {loading ? (
                      <span className="flex items-center justify-center gap-2">
                        <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                        {isSignUp ? 'Creating Account...' : 'Signing In...'}
                      </span>
                    ) : (
                      isSignUp ? 'Create Account' : 'Sign In'
                    )}
                  </button>
                </form>

                {/* Divider */}
                <div className="relative my-7">
                  <div className="absolute inset-0 flex items-center">
                    <div className="w-full border-t border-white/10"></div>
                  </div>
                  <div className="relative flex justify-center text-xs">
                    <span className="px-3 py-1 bg-slate-900/80 text-blue-200/50 rounded-full">Email/Password Only</span>
                  </div>
                </div>

                {/* Social Login Disabled Notice */}
                <div className="bg-blue-500/5 border border-blue-400/10 rounded-xl p-3.5 text-center">
                  <p className="text-xs text-blue-200/50 flex items-center justify-center gap-2">
                    <Lock className="h-3.5 w-3.5" />
                    Secure authentication with email & password
                  </p>
                </div>

                {/* Sign Up Link */}
                <div className="mt-6 text-center">
                  <p className="text-sm text-blue-200/60">
                    {isSignUp ? 'Already have an account?' : 'Don\'t have an account?'}{' '}
                    <button 
                      type="button" 
                      className="text-cyan-400 hover:text-cyan-300 font-medium transition-colors" 
                      onClick={() => {
                        setIsSignUp(!isSignUp);
                        setError('');
                        setSuccess('');
                      }}
                    >
                      {isSignUp ? 'Sign in' : 'Sign up'}
                    </button>
                  </p>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Demo Info */}
          {!isSignUp && (
            <motion.div 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6 }}
              className="mt-6 bg-cyan-500/5 backdrop-blur-xl rounded-xl p-4 border border-cyan-400/10"
            >
              <p className="text-sm text-cyan-300/90 text-center mb-1">First time here?</p>
              <p className="text-xs text-blue-200/50 text-center">
                Click "Sign up" above to create your account with your email
              </p>
            </motion.div>
          )}
        </div>
      </div>
    </div>
  );
}