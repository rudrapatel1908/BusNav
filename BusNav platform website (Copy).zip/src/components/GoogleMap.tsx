import { useEffect, useRef, useState } from 'react';
import { GOOGLE_MAPS_API_KEY, USE_GOOGLE_MAPS } from '../config';
import { CustomMap } from './CustomMap';

interface Location {
  lat: number;
  lng: number;
}

interface Marker {
  id: string;
  location: Location;
  label: string;
  color: string;
  onClick?: () => void;
}

interface GoogleMapProps {
  center: Location;
  userLocation: Location;
  markers: Marker[];
  onMarkerClick?: (markerId: string) => void;
  zoom?: number;
  universityLocation?: Location;
  pickupLocation?: Location;
  selectedBusForRoute?: { id: string; location: Location } | null;
  onRouteInfoUpdate?: (info: {
    leg1Distance: string;
    leg1Duration: string;
    leg2Distance: string;
    leg2Duration: string;
  } | null) => void;
}

// Load Google Maps script
const loadGoogleMapsScript = (apiKey: string): Promise<void> => {
  return new Promise((resolve, reject) => {
    // Check if already loaded
    if (window.google && window.google.maps) {
      resolve();
      return;
    }

    // Check if script is already being loaded
    const existingScript = document.querySelector(
      `script[src*="maps.googleapis.com/maps/api"]`
    );
    if (existingScript) {
      existingScript.addEventListener('load', () => {
        // Wait a bit for Google Maps to fully initialize
        const checkGoogleMaps = setInterval(() => {
          if (window.google && window.google.maps && window.google.maps.Map) {
            clearInterval(checkGoogleMaps);
            resolve();
          }
        }, 100);
      });
      existingScript.addEventListener('error', reject);
      return;
    }

    // Create callback function
    const callbackName = 'initGoogleMaps_' + Date.now();
    (window as any)[callbackName] = () => {
      delete (window as any)[callbackName];
      resolve();
    };

    const script = document.createElement('script');
    script.src = `https://maps.googleapis.com/maps/api/js?key=${apiKey}&callback=${callbackName}&loading=async`;
    script.async = true;
    script.defer = true;
    script.addEventListener('error', (error) => {
      delete (window as any)[callbackName];
      reject(error);
    });
    document.head.appendChild(script);
  });
};

export function GoogleMap({ 
  center, 
  userLocation, 
  markers, 
  onMarkerClick, 
  zoom = 14,
  universityLocation,
  pickupLocation,
  selectedBusForRoute,
  onRouteInfoUpdate
}: GoogleMapProps) {
  const mapRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<google.maps.Map | null>(null);
  const markersRef = useRef<any[]>([]);
  const userMarkerRef = useRef<any>(null);
  const universityMarkerRef = useRef<any>(null);
  const pickupMarkerRef = useRef<any>(null);
  const circleRef = useRef<google.maps.Circle | null>(null);
  const pathLinesRef = useRef<google.maps.Polyline[]>([]);
  const routePathLinesRef = useRef<google.maps.Polyline[]>([]);
  const directionsRenderersRef = useRef<google.maps.DirectionsRenderer[]>([]);
  const [isLoaded, setIsLoaded] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [routeInfo, setRouteInfo] = useState<{
    leg1Distance: string;
    leg1Duration: string;
    leg2Distance: string;
    leg2Duration: string;
  } | null>(null);
  const [hoveredMarkerId, setHoveredMarkerId] = useState<string | null>(null);
  const [hasBillingError, setHasBillingError] = useState(false);
  const routeInfoRef = useRef<string>(''); // Track route info to prevent infinite loops

  // Load Google Maps script
  useEffect(() => {
    if (!USE_GOOGLE_MAPS) {
      setError('GOOGLE_MAPS_DISABLED');
      return;
    }

    if (GOOGLE_MAPS_API_KEY === 'YOUR_GOOGLE_MAPS_API_KEY_HERE') {
      setError('API_KEY_MISSING');
      return;
    }

    // Suppress Google Maps console errors but don't trigger fallback
    const originalConsoleError = console.error;
    const originalConsoleWarn = console.warn;
    
    console.error = (...args) => {
      // Suppress Google Maps billing errors silently
      const message = args.join(' ');
      if (
        message.includes('BillingNotEnabled') ||
        message.includes('billing') ||
        message.includes('REQUEST_DENIED') ||
        message.includes('DIRECTIONS_ROUTE') ||
        message.includes('MapsRequestError')
      ) {
        // Mark that we have billing issues but don't prevent map from loading
        setHasBillingError(true);
        return; // Silently suppress the error
      }
      originalConsoleError.apply(console, args);
    };

    console.warn = (...args) => {
      // Suppress Google Maps deprecation warnings for Marker API
      const message = args.join(' ');
      if (
        message.includes('google.maps.Marker is deprecated') ||
        message.includes('AdvancedMarkerElement') ||
        message.includes('February 21st, 2024')
      ) {
        return; // Silently suppress the deprecation warning
      }
      originalConsoleWarn.apply(console, args);
    };

    // Listen for Google Maps errors
    const handleGoogleMapsError = (e: ErrorEvent) => {
      if (e.message && (e.message.includes('BillingNotEnabled') || e.message.includes('billing'))) {
        setHasBillingError(true);
        e.preventDefault(); // Prevent error from showing in console
      }
    };

    // Also check for global gm_authFailure callback
    (window as any).gm_authFailure = () => {
      setHasBillingError(true);
    };

    window.addEventListener('error', handleGoogleMapsError);

    loadGoogleMapsScript(GOOGLE_MAPS_API_KEY)
      .then(() => setIsLoaded(true))
      .catch((err) => {
        console.error('Error loading Google Maps:', err);
        setError('LOAD_ERROR');
      });

    return () => {
      window.removeEventListener('error', handleGoogleMapsError);
      console.error = originalConsoleError;
      console.warn = originalConsoleWarn;
    };
  }, []);

  // Initialize map
  useEffect(() => {
    if (!isLoaded || !mapRef.current || mapInstanceRef.current) return;

    try {
      const map = new google.maps.Map(mapRef.current, {
        center,
        zoom,
        styles: [
          {
            featureType: 'all',
            elementType: 'geometry',
            stylers: [{ color: '#242f3e' }],
          },
          {
            featureType: 'all',
            elementType: 'labels.text.stroke',
            stylers: [{ color: '#242f3e' }],
          },
          {
            featureType: 'all',
            elementType: 'labels.text.fill',
            stylers: [{ color: '#746855' }],
          },
          {
            featureType: 'water',
            elementType: 'geometry',
            stylers: [{ color: '#17263c' }],
          },
          {
            featureType: 'road',
            elementType: 'geometry',
            stylers: [{ color: '#38414e' }],
          },
          {
            featureType: 'poi',
            elementType: 'geometry',
            stylers: [{ color: '#263c3f' }],
          },
        ],
        mapTypeControl: true,
        streetViewControl: false,
        fullscreenControl: true,
      });

      mapInstanceRef.current = map;
    } catch (err) {
      console.error('Error initializing map:', err);
      setError('Failed to initialize map');
    }
  }, [isLoaded, center, zoom]);

  // Update center when it changes
  useEffect(() => {
    if (mapInstanceRef.current && center) {
      mapInstanceRef.current.setCenter(center);
    }
  }, [center]);

  // Update user location marker and circle
  useEffect(() => {
    if (!isLoaded || !mapInstanceRef.current) return;

    // Remove existing user marker and circle
    if (userMarkerRef.current) {
      userMarkerRef.current.setMap(null);
    }
    if (circleRef.current) {
      circleRef.current.setMap(null);
    }

    // Create user location marker
    userMarkerRef.current = new google.maps.Marker({
      position: userLocation,
      map: mapInstanceRef.current,
      icon: {
        path: google.maps.SymbolPath.CIRCLE,
        scale: 10,
        fillColor: '#3b82f6',
        fillOpacity: 1,
        strokeColor: '#ffffff',
        strokeWeight: 2,
      },
      title: 'Your Location',
    });

    // Create 1km radius circle
    circleRef.current = new google.maps.Circle({
      map: mapInstanceRef.current,
      center: userLocation,
      radius: 1000, // 1km in meters
      fillColor: '#ef4444',
      fillOpacity: 0.1,
      strokeColor: '#ef4444',
      strokeOpacity: 0.5,
      strokeWeight: 2,
    });
  }, [isLoaded, userLocation]);

  // Update bus markers
  useEffect(() => {
    if (!isLoaded || !mapInstanceRef.current) return;

    // Clear existing markers
    markersRef.current.forEach((marker) => {
      marker.setMap(null);
    });
    markersRef.current = [];

    // Create new markers
    markers.forEach((markerData) => {
      const marker = new google.maps.Marker({
        position: markerData.location,
        map: mapInstanceRef.current,
        icon: {
          path: google.maps.SymbolPath.CIRCLE,
          scale: 12,
          fillColor: markerData.color,
          fillOpacity: 1,
          strokeColor: '#ffffff',
          strokeWeight: 3,
        },
        title: markerData.label,
      });

      // Add click listener
      marker.addListener('click', () => {
        if (onMarkerClick) {
          onMarkerClick(markerData.id);
        }
      });

      // Add hover listeners
      marker.addListener('mouseover', () => {
        setHoveredMarkerId(markerData.id);
      });
      marker.addListener('mouseout', () => {
        setHoveredMarkerId(null);
      });

      markersRef.current.push(marker);
    });
  }, [isLoaded, markers, onMarkerClick]);

  // Update university location marker
  useEffect(() => {
    if (!isLoaded || !mapInstanceRef.current || !universityLocation) return;

    // Remove existing university marker
    if (universityMarkerRef.current) {
      universityMarkerRef.current.setMap(null);
    }

    // Create university location marker
    universityMarkerRef.current = new google.maps.Marker({
      position: universityLocation,
      map: mapInstanceRef.current,
      icon: {
        path: google.maps.SymbolPath.CIRCLE,
        scale: 10,
        fillColor: '#65a30d',
        fillOpacity: 1,
        strokeColor: '#ffffff',
        strokeWeight: 2,
      },
      title: 'University Location',
    });
  }, [isLoaded, universityLocation]);

  // Update pickup location marker
  useEffect(() => {
    if (!isLoaded || !mapInstanceRef.current || !pickupLocation) return;

    // Remove existing pickup marker
    if (pickupMarkerRef.current) {
      pickupMarkerRef.current.setMap(null);
    }

    // Create pickup location marker
    pickupMarkerRef.current = new google.maps.Marker({
      position: pickupLocation,
      map: mapInstanceRef.current,
      icon: {
        path: google.maps.SymbolPath.CIRCLE,
        scale: 10,
        fillColor: '#f97316',
        fillOpacity: 1,
        strokeColor: '#ffffff',
        strokeWeight: 2,
      },
      title: 'Pickup Location',
    });
  }, [isLoaded, pickupLocation]);

  // Draw path on hover
  useEffect(() => {
    if (!isLoaded || !mapInstanceRef.current || !hoveredMarkerId || !universityLocation) {
      // Clear existing paths
      pathLinesRef.current.forEach((path) => path.setMap(null));
      pathLinesRef.current = [];
      return;
    }

    // Find the hovered bus marker
    const hoveredMarker = markers.find(m => m.id === hoveredMarkerId);
    if (!hoveredMarker) return;

    // Clear existing paths
    pathLinesRef.current.forEach((path) => path.setMap(null));
    pathLinesRef.current = [];

    // Create path: Bus -> Student -> University
    const pathCoordinates = [
      hoveredMarker.location, // Bus location
      userLocation,            // Student location
      universityLocation       // University location
    ];

    // Draw path from bus to student
    const pathBusToStudent = new google.maps.Polyline({
      path: [hoveredMarker.location, userLocation],
      geodesic: true,
      strokeColor: '#06b6d4',
      strokeOpacity: 0.8,
      strokeWeight: 4,
      map: mapInstanceRef.current,
    });

    // Draw path from student to university
    const pathStudentToUniversity = new google.maps.Polyline({
      path: [userLocation, universityLocation],
      geodesic: true,
      strokeColor: '#65a30d',
      strokeOpacity: 0.8,
      strokeWeight: 4,
      map: mapInstanceRef.current,
    });

    pathLinesRef.current = [pathBusToStudent, pathStudentToUniversity];
  }, [isLoaded, hoveredMarkerId, markers, userLocation, universityLocation]);

  // Draw route for selected bus using Directions API (Bus -> Pickup -> University)
  useEffect(() => {
    if (!isLoaded || !mapInstanceRef.current) {
      // Clear existing direction renderers and route lines
      directionsRenderersRef.current.forEach((renderer) => renderer.setMap(null));
      directionsRenderersRef.current = [];
      routePathLinesRef.current.forEach((line) => line.setMap(null));
      routePathLinesRef.current = [];
      if (onRouteInfoUpdate) {
        onRouteInfoUpdate(null);
      }
      return;
    }

    if (!selectedBusForRoute || !pickupLocation || !universityLocation) {
      // Clear existing direction renderers and route lines
      directionsRenderersRef.current.forEach((renderer) => renderer.setMap(null));
      directionsRenderersRef.current = [];
      routePathLinesRef.current.forEach((line) => line.setMap(null));
      routePathLinesRef.current = [];
      // Clear route info only if it was previously set
      if (onRouteInfoUpdate && routeInfoRef.current !== '') {
        routeInfoRef.current = '';
        onRouteInfoUpdate(null);
      }
      return;
    }

    // Clear existing direction renderers and route lines
    directionsRenderersRef.current.forEach((renderer) => renderer.setMap(null));
    directionsRenderersRef.current = [];
    routePathLinesRef.current.forEach((line) => line.setMap(null));
    routePathLinesRef.current = [];

    // Helper function to calculate distance between two points (Haversine formula)
    const calculateDistance = (lat1: number, lng1: number, lat2: number, lng2: number): number => {
      const R = 6371; // Earth's radius in km
      const dLat = (lat2 - lat1) * Math.PI / 180;
      const dLng = (lng2 - lng1) * Math.PI / 180;
      const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
                Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
                Math.sin(dLng / 2) * Math.sin(dLng / 2);
      const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
      return R * c;
    };

    // Helper function to create a curved path with waypoints
    const createCurvedPath = (start: Location, end: Location, segments: number = 5): Location[] => {
      const path: Location[] = [start];
      
      for (let i = 1; i < segments; i++) {
        const ratio = i / segments;
        // Add slight curve by offsetting perpendicular to the direct line
        const midLat = start.lat + (end.lat - start.lat) * ratio;
        const midLng = start.lng + (end.lng - start.lng) * ratio;
        
        // Add slight offset to simulate road curvature (smaller offset for more realistic look)
        const offset = Math.sin(ratio * Math.PI) * 0.001;
        path.push({
          lat: midLat + offset,
          lng: midLng + offset
        });
      }
      
      path.push(end);
      return path;
    };

    // Fallback function to draw smart polylines
    const fallbackToSmartPolylines = () => {
      // Calculate distances
      const dist1 = calculateDistance(
        selectedBusForRoute.location.lat,
        selectedBusForRoute.location.lng,
        pickupLocation.lat,
        pickupLocation.lng
      );
      const dist2 = calculateDistance(
        pickupLocation.lat,
        pickupLocation.lng,
        universityLocation.lat,
        universityLocation.lng
      );

      // Create curved paths to simulate roads (more realistic than straight lines)
      const path1 = createCurvedPath(selectedBusForRoute.location, pickupLocation, 8);
      const path2 = createCurvedPath(pickupLocation, universityLocation, 8);

      // Draw path from bus to pickup (orange)
      const polyline1 = new google.maps.Polyline({
        path: path1,
        geodesic: true,
        strokeColor: '#f97316',
        strokeOpacity: 0.8,
        strokeWeight: 5,
        map: mapInstanceRef.current,
      });
      routePathLinesRef.current.push(polyline1);

      // Draw path from pickup to university (green)
      const polyline2 = new google.maps.Polyline({
        path: path2,
        geodesic: true,
        strokeColor: '#65a30d',
        strokeOpacity: 0.8,
        strokeWeight: 5,
        map: mapInstanceRef.current,
      });
      routePathLinesRef.current.push(polyline2);

      // Calculate realistic times (assuming average speed of 30 km/h in city, with road factor of 1.3)
      const roadFactor = 1.3; // Roads are typically 30% longer than straight line
      const avgSpeed = 30; // km/h
      const time1 = (dist1 * roadFactor / avgSpeed) * 60; // in minutes
      const time2 = (dist2 * roadFactor / avgSpeed) * 60; // in minutes

      // Format route information
      const routeData = {
        leg1Distance: `${(dist1 * roadFactor).toFixed(1)} km`,
        leg1Duration: `${Math.ceil(time1)} min`,
        leg2Distance: `${(dist2 * roadFactor).toFixed(1)} km`,
        leg2Duration: `${Math.ceil(time2)} min`,
      };

      // Only update if changed
      const newInfoStr = JSON.stringify(routeData);
      if (onRouteInfoUpdate && newInfoStr !== routeInfoRef.current) {
        routeInfoRef.current = newInfoStr;
        onRouteInfoUpdate(routeData);
      }
    };

    // If we already detected a billing error, skip Directions API entirely
    if (hasBillingError) {
      fallbackToSmartPolylines();
      return;
    }

    // Try Directions API only once, then remember if it failed
    const directionsService = new google.maps.DirectionsService();

    // Request directions for Bus -> Pickup
    directionsService.route(
      {
        origin: selectedBusForRoute.location,
        destination: pickupLocation,
        travelMode: google.maps.TravelMode.DRIVING,
      },
      (result, status) => {
        if (status === google.maps.DirectionsStatus.OK && result) {
          // Directions API Success - use real routes
          const renderer1 = new google.maps.DirectionsRenderer({
            map: mapInstanceRef.current,
            directions: result,
            suppressMarkers: true,
            polylineOptions: {
              strokeColor: '#f97316',
              strokeWeight: 5,
              strokeOpacity: 0.8,
            },
          });
          directionsRenderersRef.current.push(renderer1);

          const leg1 = result.routes[0].legs[0];
          
          // Request directions for Pickup -> University
          directionsService.route(
            {
              origin: pickupLocation,
              destination: universityLocation,
              travelMode: google.maps.TravelMode.DRIVING,
            },
            (result2, status2) => {
              if (status2 === google.maps.DirectionsStatus.OK && result2) {
                const renderer2 = new google.maps.DirectionsRenderer({
                  map: mapInstanceRef.current,
                  directions: result2,
                  suppressMarkers: true,
                  polylineOptions: {
                    strokeColor: '#65a30d',
                    strokeWeight: 5,
                    strokeOpacity: 0.8,
                  },
                });
                directionsRenderersRef.current.push(renderer2);

                const leg2 = result2.routes[0].legs[0];

                // Update route information with real data
                const routeData = {
                  leg1Distance: leg1.distance?.text || '',
                  leg1Duration: leg1.duration?.text || '',
                  leg2Distance: leg2.distance?.text || '',
                  leg2Duration: leg2.duration?.text || '',
                };

                if (onRouteInfoUpdate) {
                  onRouteInfoUpdate(routeData);
                }
              } else {
                // Second leg failed
                if (status2 === google.maps.DirectionsStatus.REQUEST_DENIED) {
                  setHasBillingError(true);
                }
                fallbackToSmartPolylines();
              }
            }
          );
        } else {
          // Directions API failed - remember it and use fallback
          if (status === google.maps.DirectionsStatus.REQUEST_DENIED || 
              status === google.maps.DirectionsStatus.OVER_QUERY_LIMIT) {
            setHasBillingError(true);
          }
          fallbackToSmartPolylines();
        }
      }
    );
  }, [isLoaded, selectedBusForRoute, pickupLocation, universityLocation, onRouteInfoUpdate, hasBillingError]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      markersRef.current.forEach((marker) => marker.setMap(null));
      if (userMarkerRef.current) {
        userMarkerRef.current.map = null;
      }
      if (circleRef.current) {
        circleRef.current.setMap(null);
      }
      if (universityMarkerRef.current) {
        universityMarkerRef.current.setMap(null);
      }
      if (pickupMarkerRef.current) {
        pickupMarkerRef.current.setMap(null);
      }
      pathLinesRef.current.forEach((path) => path.setMap(null));
      routePathLinesRef.current.forEach((path) => path.setMap(null));
      directionsRenderersRef.current.forEach((renderer) => renderer.setMap(null));
    };
  }, []);

  if (error) {
    // Use CustomMap as fallback - without warning if intentionally disabled
    if (error === 'GOOGLE_MAPS_DISABLED') {
      return (
        <CustomMap
          center={center}
          userLocation={userLocation}
          markers={markers}
          onMarkerClick={onMarkerClick}
          zoom={zoom}
          universityLocation={universityLocation}
          pickupLocation={pickupLocation}
          selectedBusForRoute={selectedBusForRoute}
          onRouteInfoUpdate={onRouteInfoUpdate}
        />
      );
    }

    // For API key missing or load errors, show error screen
    if (error === 'API_KEY_MISSING' || error === 'LOAD_ERROR') {
      let errorTitle = 'Map Error';
      let errorMessage = error;
      let instructions: string[] = [];

      if (error === 'API_KEY_MISSING') {
        errorTitle = 'Google Maps API Key Missing';
        errorMessage = 'Please add your Google Maps API key';
        instructions = [
          'Open /config.ts',
          'Replace YOUR_GOOGLE_MAPS_API_KEY_HERE with your actual API key',
          'Get an API key at console.cloud.google.com',
          'Enable the Maps JavaScript API'
        ];
      } else if (error === 'LOAD_ERROR') {
        errorTitle = 'Failed to Load Map';
        errorMessage = 'Could not load Google Maps';
        instructions = [
          'Check your internet connection',
          'Verify your API key is correct in /config.ts',
          'Make sure the Maps JavaScript API is enabled in Google Cloud Console',
          'Check the browser console for more details'
        ];
      }

      return (
        <div className="w-full h-full flex items-center justify-center bg-gray-900 text-white">
          <div className="text-center p-8 max-w-lg">
            <div className="text-red-500 text-4xl mb-4">⚠️</div>
            <h3 className="text-xl font-bold mb-2">{errorTitle}</h3>
            <p className="text-gray-400 mb-4">{errorMessage}</p>
            <div className="bg-gray-800 rounded-lg p-4 text-left text-sm">
              <p className="text-cyan-400 mb-2 font-semibold">To fix this:</p>
              <ol className="list-decimal list-inside space-y-2 text-gray-300">
                {instructions.map((instruction, index) => (
                  <li key={index} className="leading-relaxed">{instruction}</li>
                ))}
              </ol>
            </div>
          </div>
        </div>
      );
    }
  }

  if (!isLoaded) {
    return (
      <div className="w-full h-full flex items-center justify-center bg-gray-900">
        <div className="text-center">
          <div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-cyan-500 mx-auto mb-4"></div>
          <p className="text-white">Loading Google Maps...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="relative w-full h-full">
      <div ref={mapRef} className="w-full h-full" />
      <div className="absolute bottom-4 right-4 bg-gray-800/90 backdrop-blur-sm rounded-lg p-3 text-xs text-gray-300 shadow-lg border border-gray-700">
        <div className="flex flex-col gap-2">
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1">
              <div className="w-3 h-3 rounded-full bg-blue-500"></div>
              <span>You</span>
            </div>
            <div className="flex items-center gap-1">
              <div className="w-3 h-3 rounded-full bg-lime-600"></div>
              <span>University</span>
            </div>
            <div className="flex items-center gap-1">
              <span>🚌</span>
              <span>Buses</span>
            </div>
          </div>
          <div className="text-gray-500">Hover on bus to see route</div>
        </div>
      </div>
    </div>
  );
}