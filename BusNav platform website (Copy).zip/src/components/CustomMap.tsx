import { useEffect, useRef, useState } from 'react';

interface Location {
  lat: number;
  lng: number;
}

interface Marker {
  id: string;
  location: Location;
  label: string;
  color: string;
  onClick?: () => void;
}

interface CustomMapProps {
  center: Location;
  userLocation: Location;
  markers: Marker[];
  onMarkerClick?: (markerId: string) => void;
  zoom?: number;
  universityLocation?: Location;
  pickupLocation?: Location;
  selectedBusForRoute?: { id: string; location: Location } | null;
  onRouteInfoUpdate?: (info: {
    leg1Distance: string;
    leg1Duration: string;
    leg2Distance: string;
    leg2Duration: string;
  } | null) => void;
}

export function CustomMap({ center, userLocation, markers, onMarkerClick, zoom = 14, universityLocation, pickupLocation, selectedBusForRoute, onRouteInfoUpdate }: CustomMapProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [hoveredMarker, setHoveredMarker] = useState<string | null>(null);
  const [scale, setScale] = useState(1);
  const [offset, setOffset] = useState({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });
  const [canvasSize, setCanvasSize] = useState({ width: 800, height: 600 });
  const routeInfoRef = useRef<string>(''); // Track route info to prevent loops

  // Update canvas size when container resizes
  useEffect(() => {
    const updateCanvasSize = () => {
      if (containerRef.current) {
        const { width, height } = containerRef.current.getBoundingClientRect();
        // Only update if we have valid dimensions
        if (width > 0 && height > 0) {
          setCanvasSize({ width, height });
        }
      }
    };

    // Use a slight delay to ensure container is rendered
    const timeoutId = setTimeout(updateCanvasSize, 100);
    
    // Also try immediately
    updateCanvasSize();
    
    window.addEventListener('resize', updateCanvasSize);
    return () => {
      clearTimeout(timeoutId);
      window.removeEventListener('resize', updateCanvasSize);
    };
  }, []);

  // Convert lat/lng to canvas coordinates
  const latLngToPixel = (lat: number, lng: number, canvasWidth: number, canvasHeight: number) => {
    // Simple mercator projection
    const scale = Math.pow(2, zoom) * 256 / 360;
    const centerX = canvasWidth / 2;
    const centerY = canvasHeight / 2;

    const x = centerX + (lng - center.lng) * scale + offset.x;
    const y = centerY - (lat - center.lat) * scale + offset.y;

    return { x, y };
  };

  // Draw grid lines for background
  const drawGrid = (ctx: CanvasRenderingContext2D, width: number, height: number) => {
    ctx.strokeStyle = '#374151';
    ctx.lineWidth = 1;

    // Vertical lines
    for (let x = 0; x < width; x += 50) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, height);
      ctx.stroke();
    }

    // Horizontal lines
    for (let y = 0; y < height; y += 50) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(width, y);
      ctx.stroke();
    }
  };

  // Draw a marker
  const drawMarker = (
    ctx: CanvasRenderingContext2D,
    x: number,
    y: number,
    label: string,
    color: string,
    isHovered: boolean
  ) => {
    // Draw pin shape
    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.arc(x, y - 15, 10, 0, Math.PI * 2);
    ctx.fill();
    
    // Draw pin bottom
    ctx.beginPath();
    ctx.moveTo(x, y - 5);
    ctx.lineTo(x - 5, y - 10);
    ctx.lineTo(x + 5, y - 10);
    ctx.closePath();
    ctx.fill();

    // Draw label
    if (isHovered) {
      ctx.font = 'bold 12px sans-serif';
      ctx.fillStyle = '#ffffff';
      ctx.textAlign = 'center';
      ctx.fillText(label, x, y - 30);
    }

    // Draw emoji icon
    ctx.font = '20px sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(label === '📍' ? '📍' : '🚌', x, y - 15);
  };

  // Handle mouse move for hover effect
  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!canvasRef.current) return;

    if (isDragging) {
      const dx = e.clientX - dragStart.x;
      const dy = e.clientY - dragStart.y;
      setOffset({ x: offset.x + dx, y: offset.y + dy });
      setDragStart({ x: e.clientX, y: e.clientY });
      return;
    }

    const rect = canvasRef.current.getBoundingClientRect();
    const mouseX = e.clientX - rect.left;
    const mouseY = e.clientY - rect.top;

    let found = false;
    for (const marker of markers) {
      const pos = latLngToPixel(marker.location.lat, marker.location.lng, rect.width, rect.height);
      const distance = Math.sqrt(Math.pow(pos.x - mouseX, 2) + Math.pow(pos.y - mouseY, 2));
      
      if (distance < 15) {
        setHoveredMarker(marker.id);
        found = true;
        break;
      }
    }

    if (!found) {
      setHoveredMarker(null);
    }
  };

  // Handle mouse click on markers
  const handleClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!canvasRef.current) return;

    const rect = canvasRef.current.getBoundingClientRect();
    const mouseX = e.clientX - rect.left;
    const mouseY = e.clientY - rect.top;

    for (const marker of markers) {
      const pos = latLngToPixel(marker.location.lat, marker.location.lng, rect.width, rect.height);
      const distance = Math.sqrt(Math.pow(pos.x - mouseX, 2) + Math.pow(pos.y - mouseY, 2));
      
      if (distance < 15) {
        onMarkerClick?.(marker.id);
        break;
      }
    }
  };

  // Mouse down for dragging
  const handleMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    setIsDragging(true);
    setDragStart({ x: e.clientX, y: e.clientY });
  };

  // Mouse up to stop dragging
  const handleMouseUp = () => {
    setIsDragging(false);
  };

  // Mouse wheel for zooming
  const handleWheel = (e: React.WheelEvent<HTMLCanvasElement>) => {
    e.preventDefault();
    const delta = e.deltaY > 0 ? -0.1 : 0.1;
    setScale(Math.max(0.5, Math.min(3, scale + delta)));
  };

  // Draw the map
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;

    // Clear canvas
    ctx.fillStyle = '#1f2937';
    ctx.fillRect(0, 0, width, height);

    // Draw grid
    drawGrid(ctx, width, height);

    // Draw roads/streets (decorative)
    ctx.strokeStyle = '#4b5563';
    ctx.lineWidth = 3;
    for (let i = 0; i < 10; i++) {
      const angle = (i / 10) * Math.PI * 2;
      const startX = width / 2;
      const startY = height / 2;
      const endX = startX + Math.cos(angle) * Math.min(width, height) / 2;
      const endY = startY + Math.sin(angle) * Math.min(width, height) / 2;
      
      ctx.beginPath();
      ctx.moveTo(startX, startY);
      ctx.lineTo(endX, endY);
      ctx.stroke();
    }

    // Draw route for selected bus if available
    if (selectedBusForRoute && pickupLocation && universityLocation) {
      const busPos = latLngToPixel(selectedBusForRoute.location.lat, selectedBusForRoute.location.lng, width, height);
      const pickupPos = latLngToPixel(pickupLocation.lat, pickupLocation.lng, width, height);
      const uniPos = latLngToPixel(universityLocation.lat, universityLocation.lng, width, height);

      // Helper function to calculate distance
      const calculateDistance = (lat1: number, lng1: number, lat2: number, lng2: number): number => {
        const R = 6371; // Earth's radius in km
        const dLat = (lat2 - lat1) * Math.PI / 180;
        const dLng = (lng2 - lng1) * Math.PI / 180;
        const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
                  Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
                  Math.sin(dLng / 2) * Math.sin(dLng / 2);
        const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        return R * c;
      };

      // Calculate distances
      const dist1 = calculateDistance(
        selectedBusForRoute.location.lat,
        selectedBusForRoute.location.lng,
        pickupLocation.lat,
        pickupLocation.lng
      );
      const dist2 = calculateDistance(
        pickupLocation.lat,
        pickupLocation.lng,
        universityLocation.lat,
        universityLocation.lng
      );

      // Calculate realistic times
      const roadFactor = 1.3;
      const avgSpeed = 30;
      const time1 = (dist1 * roadFactor / avgSpeed) * 60;
      const time2 = (dist2 * roadFactor / avgSpeed) * 60;

      // Update route info only if it changed
      if (onRouteInfoUpdate) {
        const newInfo = {
          leg1Distance: `${(dist1 * roadFactor).toFixed(1)} km`,
          leg1Duration: `${Math.ceil(time1)} min`,
          leg2Distance: `${(dist2 * roadFactor).toFixed(1)} km`,
          leg2Duration: `${Math.ceil(time2)} min`,
        };
        const newInfoStr = JSON.stringify(newInfo);
        if (newInfoStr !== routeInfoRef.current) {
          routeInfoRef.current = newInfoStr;
          onRouteInfoUpdate(newInfo);
        }
      }

      // Draw path from bus to pickup (orange)
      ctx.strokeStyle = '#f97316';
      ctx.lineWidth = 5;
      ctx.setLineDash([]);
      ctx.beginPath();
      ctx.moveTo(busPos.x, busPos.y - 15);
      ctx.lineTo(pickupPos.x, pickupPos.y);
      ctx.stroke();

      // Draw path from pickup to university (green)
      ctx.strokeStyle = '#65a30d';
      ctx.lineWidth = 5;
      ctx.beginPath();
      ctx.moveTo(pickupPos.x, pickupPos.y);
      ctx.lineTo(uniPos.x, uniPos.y);
      ctx.stroke();

      // Draw pickup marker (orange circle)
      ctx.fillStyle = '#f97316';
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(pickupPos.x, pickupPos.y, 10, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
    }
    // Draw path lines if a bus is hovered (and no selected route)
    else if (hoveredMarker && universityLocation) {
      // Clear route info when no bus is selected
      if (onRouteInfoUpdate && routeInfoRef.current !== '') {
        routeInfoRef.current = '';
        onRouteInfoUpdate(null);
      }

      const hoveredBus = markers.find(m => m.id === hoveredMarker);
      if (hoveredBus) {
        const busPos = latLngToPixel(hoveredBus.location.lat, hoveredBus.location.lng, width, height);
        const userPos = latLngToPixel(userLocation.lat, userLocation.lng, width, height);
        const uniPos = latLngToPixel(universityLocation.lat, universityLocation.lng, width, height);

        // Draw path from bus to student (cyan)
        ctx.strokeStyle = '#06b6d4';
        ctx.lineWidth = 4;
        ctx.setLineDash([]);
        ctx.beginPath();
        ctx.moveTo(busPos.x, busPos.y - 15);
        ctx.lineTo(userPos.x, userPos.y - 15);
        ctx.stroke();

        // Draw path from student to university (green)
        ctx.strokeStyle = '#65a30d';
        ctx.lineWidth = 4;
        ctx.beginPath();
        ctx.moveTo(userPos.x, userPos.y - 15);
        ctx.lineTo(uniPos.x, uniPos.y);
        ctx.stroke();
      }
    } else {
      // Clear route info when nothing is selected/hovered
      if (onRouteInfoUpdate && routeInfoRef.current !== '') {
        routeInfoRef.current = '';
        onRouteInfoUpdate(null);
      }
    }

    // Draw user location marker (blue circle)
    const userPos = latLngToPixel(userLocation.lat, userLocation.lng, width, height);
    ctx.fillStyle = '#3b82f6';
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(userPos.x, userPos.y - 15, 10, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();

    // Draw 1km radius circle around user
    const radiusInPixels = (1 / 111) * Math.pow(2, zoom) * 256 / 360; // Approx 1km in pixels
    ctx.strokeStyle = '#ef4444';
    ctx.setLineDash([5, 5]);
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(userPos.x, userPos.y - 15, radiusInPixels, 0, Math.PI * 2);
    ctx.stroke();
    ctx.setLineDash([]);

    // Draw university location (lime/green circle)
    if (universityLocation) {
      const universityPos = latLngToPixel(universityLocation.lat, universityLocation.lng, width, height);
      ctx.fillStyle = '#65a30d';
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(universityPos.x, universityPos.y, 10, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
    }

    // Draw bus markers
    for (const marker of markers) {
      const pos = latLngToPixel(marker.location.lat, marker.location.lng, width, height);
      const isHovered = hoveredMarker === marker.id;
      drawMarker(ctx, pos.x, pos.y, marker.label, marker.color, isHovered);
    }
  }, [center, userLocation, markers, hoveredMarker, zoom, offset, scale, canvasSize, universityLocation, pickupLocation, selectedBusForRoute, onRouteInfoUpdate]);

  return (
    <div className="relative w-full h-full bg-gray-900" ref={containerRef}>
      <canvas
        ref={canvasRef}
        width={canvasSize.width}
        height={canvasSize.height}
        className="cursor-move"
        onMouseMove={handleMouseMove}
        onMouseDown={handleMouseDown}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
        onClick={handleClick}
        onWheel={handleWheel}
        style={{ 
          cursor: isDragging ? 'grabbing' : 'grab',
          width: '100%',
          height: '100%',
          display: 'block'
        }}
      />
      <div className="absolute bottom-4 right-4 bg-gray-800 rounded-lg p-2 text-xs text-gray-400">
        <div className="flex flex-col gap-2">
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1">
              <div className="w-3 h-3 rounded-full bg-blue-500"></div>
              <span>You</span>
            </div>
            <div className="flex items-center gap-1">
              <div className="w-3 h-3 rounded-full bg-lime-600"></div>
              <span>University</span>
            </div>
            <div className="flex items-center gap-1">
              <span>🚌</span>
              <span>Buses</span>
            </div>
          </div>
          <div className="text-gray-500">Hover on bus to see route</div>
        </div>
      </div>
    </div>
  );
}