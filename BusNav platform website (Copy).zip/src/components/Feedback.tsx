import { useState } from 'react';
import { Star, Send, MessageSquare, ThumbsUp, User, Calendar } from 'lucide-react';

interface FeedbackItem {
  id: string;
  driverId: string;
  driverName: string;
  busRoute: string;
  rating: number;
  comment: string;
  date: string;
  userType: 'student' | 'parent';
  userName: string;
}

interface FeedbackProps {
  university: string;
  userType: 'student' | 'parent';
  userEmail: string;
}

// Mock feedback data
const MOCK_FEEDBACK: FeedbackItem[] = [
  {
    id: '1',
    driverId: 'DRV001',
    driverName: 'Rajesh Kumar',
    busRoute: 'Route A - Main Campus',
    rating: 5,
    comment: 'Very punctual and drives safely. Always maintains the bus clean.',
    date: '2026-01-28',
    userType: 'student',
    userName: 'Priya Sharma'
  },
  {
    id: '2',
    driverId: 'DRV002',
    driverName: 'Suresh Patel',
    busRoute: 'Route B - North Campus',
    rating: 4,
    comment: 'Good driver, but sometimes runs a few minutes late.',
    date: '2026-01-27',
    userType: 'parent',
    userName: 'Amit Singh'
  },
  {
    id: '3',
    driverId: 'DRV001',
    driverName: 'Rajesh Kumar',
    busRoute: 'Route A - Main Campus',
    rating: 5,
    comment: 'Excellent service! Very courteous and professional.',
    date: '2026-01-26',
    userType: 'student',
    userName: 'Ananya Reddy'
  },
  {
    id: '4',
    driverId: 'DRV003',
    driverName: 'Vijay Deshmukh',
    busRoute: 'Route C - South Campus',
    rating: 4,
    comment: 'Reliable and friendly. Makes everyone feel comfortable.',
    date: '2026-01-25',
    userType: 'parent',
    userName: 'Lakshmi Iyer'
  },
];

// Indian driver names for different universities
const DRIVER_DATA: { [key: string]: { id: string; name: string; route: string }[] } = {
  'SRM AP University': [
    { id: 'DRV001', name: 'Rajesh Kumar', route: 'Route A - Main Campus' },
    { id: 'DRV002', name: 'Suresh Patel', route: 'Route B - North Campus' },
    { id: 'DRV003', name: 'Vijay Deshmukh', route: 'Route C - South Campus' },
    { id: 'DRV004', name: 'Prakash Reddy', route: 'Route D - East Campus' },
    { id: 'DRV005', name: 'Arun Singh', route: 'Route E - West Campus' },
    { id: 'DRV006', name: 'Mohan Rao', route: 'Route F - Hostel Area' },
  ],
  'IIT Madras': [
    { id: 'DRV001', name: 'Murugan Pillai', route: 'Route A - Main Gate' },
    { id: 'DRV002', name: 'Selvam Kumar', route: 'Route B - Hostel Zone' },
    { id: 'DRV003', name: 'Karthik Subramanian', route: 'Route C - Academic Block' },
    { id: 'DRV004', name: 'Ravi Chandran', route: 'Route D - Research Park' },
    { id: 'DRV005', name: 'Balu Narayanan', route: 'Route E - Sports Complex' },
    { id: 'DRV006', name: 'Senthil Raja', route: 'Route F - Library Circle' },
  ],
  'IIT Delhi': [
    { id: 'DRV001', name: 'Ramesh Sharma', route: 'Route A - Main Campus' },
    { id: 'DRV002', name: 'Dinesh Verma', route: 'Route B - Hostel Area' },
    { id: 'DRV003', name: 'Ashok Gupta', route: 'Route C - Academic Zone' },
    { id: 'DRV004', name: 'Vijay Kumar', route: 'Route D - Sports Block' },
    { id: 'DRV005', name: 'Sunil Chauhan', route: 'Route E - Admin Block' },
    { id: 'DRV006', name: 'Rakesh Singh', route: 'Route F - Medical Center' },
  ],
  'IIT Bombay': [
    { id: 'DRV001', name: 'Santosh Patil', route: 'Route A - Main Gate' },
    { id: 'DRV002', name: 'Ganesh Joshi', route: 'Route B - Hostel Complex' },
    { id: 'DRV003', name: 'Mahesh Kulkarni', route: 'Route C - Academic Area' },
    { id: 'DRV004', name: 'Sanjay Pawar', route: 'Route D - Tech Park' },
    { id: 'DRV005', name: 'Dilip Shinde', route: 'Route E - Central Library' },
    { id: 'DRV006', name: 'Anil Rane', route: 'Route F - Sports Facility' },
  ],
  'BITS Pilani': [
    { id: 'DRV001', name: 'Gopal Sharma', route: 'Route A - Academic Block' },
    { id: 'DRV002', name: 'Mahendra Singh', route: 'Route B - Hostel Zone' },
    { id: 'DRV003', name: 'Bharat Joshi', route: 'Route C - New Campus' },
    { id: 'DRV004', name: 'Deepak Rathore', route: 'Route D - Old Campus' },
    { id: 'DRV005', name: 'Naresh Choudhary', route: 'Route E - Sports Ground' },
    { id: 'DRV006', name: 'Pawan Meena', route: 'Route F - Library Block' },
  ],
  'VIT Vellore': [
    { id: 'DRV001', name: 'Karthikeyan Rajan', route: 'Route A - Main Block' },
    { id: 'DRV002', name: 'Murugan Selvam', route: 'Route B - Hostel Area' },
    { id: 'DRV003', name: 'Prakash Venkat', route: 'Route C - Tech Tower' },
    { id: 'DRV004', name: 'Babu Krishnan', route: 'Route D - Sports Complex' },
    { id: 'DRV005', name: 'Ganesh Sundaram', route: 'Route E - Library Wing' },
    { id: 'DRV006', name: 'Ravi Moorthy', route: 'Route F - Medical Block' },
  ],
  'NIT Trichy': [
    { id: 'DRV001', name: 'Arumugam Pillai', route: 'Route A - Main Campus' },
    { id: 'DRV002', name: 'Senthilkumar Raja', route: 'Route B - Hostel Zone' },
    { id: 'DRV003', name: 'Manikandan Kumar', route: 'Route C - Academic Block' },
    { id: 'DRV004', name: 'Rajendran Murugan', route: 'Route D - Central Library' },
    { id: 'DRV005', name: 'Chandran Selvam', route: 'Route E - Sports Arena' },
    { id: 'DRV006', name: 'Vinod Raman', route: 'Route F - Tech Park' },
  ],
  'IIIT Hyderabad': [
    { id: 'DRV001', name: 'Narasimha Rao', route: 'Route A - Main Campus' },
    { id: 'DRV002', name: 'Venkatesh Reddy', route: 'Route B - Hostel Block' },
    { id: 'DRV003', name: 'Srikanth Kumar', route: 'Route C - Academic Zone' },
    { id: 'DRV004', name: 'Ramakrishna Goud', route: 'Route D - Research Center' },
    { id: 'DRV005', name: 'Mahesh Chary', route: 'Route E - Library Circle' },
    { id: 'DRV006', name: 'Suresh Naidu', route: 'Route F - Sports Ground' },
  ],
  'IIT Kanpur': [
    { id: 'DRV001', name: 'Rajendra Tiwari', route: 'Route A - Main Gate' },
    { id: 'DRV002', name: 'Manoj Yadav', route: 'Route B - Hall Area' },
    { id: 'DRV003', name: 'Shyam Pandey', route: 'Route C - Academic Block' },
    { id: 'DRV004', name: 'Krishna Mishra', route: 'Route D - New Campus' },
    { id: 'DRV005', name: 'Amar Singh', route: 'Route E - Old Campus' },
    { id: 'DRV006', name: 'Bhola Gupta', route: 'Route F - Sports Complex' },
  ],
  'IIT Kharagpur': [
    { id: 'DRV001', name: 'Subhas Mondal', route: 'Route A - Main Campus' },
    { id: 'DRV002', name: 'Ranjan Das', route: 'Route B - Hall Zone' },
    { id: 'DRV003', name: 'Tapan Ghosh', route: 'Route C - Academic Area' },
    { id: 'DRV004', name: 'Debasis Sen', route: 'Route D - Tech Market' },
    { id: 'DRV005', name: 'Amit Chatterjee', route: 'Route E - Library Square' },
    { id: 'DRV006', name: 'Biswajit Roy', route: 'Route F - Sports Ground' },
  ],
  'Anna University': [
    { id: 'DRV001', name: 'Saravanan Muthu', route: 'Route A - Main Block' },
    { id: 'DRV002', name: 'Kumaran Palani', route: 'Route B - Hostel Area' },
    { id: 'DRV003', name: 'Balaji Srinivasan', route: 'Route C - Tech Park' },
    { id: 'DRV004', name: 'Mani Kandan', route: 'Route D - Library Wing' },
    { id: 'DRV005', name: 'Prabhu Rajan', route: 'Route E - Sports Complex' },
    { id: 'DRV006', name: 'Selvakumar Raja', route: 'Route F - Admin Block' },
  ],
  'Jadavpur University': [
    { id: 'DRV001', name: 'Somnath Banerjee', route: 'Route A - Main Campus' },
    { id: 'DRV002', name: 'Partha Sarkar', route: 'Route B - New Building' },
    { id: 'DRV003', name: 'Anirban Mukherjee', route: 'Route C - Library Block' },
    { id: 'DRV004', name: 'Dipak Ghosh', route: 'Route D - Science Block' },
    { id: 'DRV005', name: 'Sujit Chakraborty', route: 'Route E - Arts Block' },
    { id: 'DRV006', name: 'Prasenjit Dutta', route: 'Route F - Sports Ground' },
  ],
  'Manipal Institute of Technology': [
    { id: 'DRV001', name: 'Sudhir Shetty', route: 'Route A - Main Campus' },
    { id: 'DRV002', name: 'Raghav Rao', route: 'Route B - Hostel Block' },
    { id: 'DRV003', name: 'Harish Bhat', route: 'Route C - Academic Zone' },
    { id: 'DRV004', name: 'Naveen Hegde', route: 'Route D - Tech Center' },
    { id: 'DRV005', name: 'Mohan Acharya', route: 'Route E - Library Wing' },
    { id: 'DRV006', name: 'Ganesh Nayak', route: 'Route F - Sports Arena' },
  ],
  'Delhi University': [
    { id: 'DRV001', name: 'Krishan Kumar', route: 'Route A - North Campus' },
    { id: 'DRV002', name: 'Harish Chand', route: 'Route B - South Campus' },
    { id: 'DRV003', name: 'Mukesh Rana', route: 'Route C - Central Library' },
    { id: 'DRV004', name: 'Prem Singh', route: 'Route D - Arts Faculty' },
    { id: 'DRV005', name: 'Yogesh Sharma', route: 'Route E - Science Block' },
    { id: 'DRV006', name: 'Santosh Rawat', route: 'Route F - Sports Complex' },
  ],
  'Amity University': [
    { id: 'DRV001', name: 'Devendra Kumar', route: 'Route A - Main Campus' },
    { id: 'DRV002', name: 'Sanjay Tyagi', route: 'Route B - Hostel Zone' },
    { id: 'DRV003', name: 'Ajay Saxena', route: 'Route C - Academic Block' },
    { id: 'DRV004', name: 'Vinod Agarwal', route: 'Route D - Library Block' },
    { id: 'DRV005', name: 'Rajeev Mittal', route: 'Route E - Sports Ground' },
    { id: 'DRV006', name: 'Anuj Bansal', route: 'Route F - Tech Park' },
  ],
};

export function Feedback({ university, userType, userEmail }: FeedbackProps) {
  const [selectedDriver, setSelectedDriver] = useState<string>('');
  const [rating, setRating] = useState<number>(0);
  const [hoverRating, setHoverRating] = useState<number>(0);
  const [comment, setComment] = useState<string>('');
  const [feedbackList, setFeedbackList] = useState<FeedbackItem[]>(MOCK_FEEDBACK);
  const [activeTab, setActiveTab] = useState<'submit' | 'history'>('submit');
  const [filterDriver, setFilterDriver] = useState<string>('all');

  const drivers = DRIVER_DATA[university] || DRIVER_DATA['SRM AP University'];

  const handleSubmitFeedback = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedDriver || rating === 0) {
      alert('Please select a driver and provide a rating.');
      return;
    }

    const driver = drivers.find(d => d.id === selectedDriver);
    if (!driver) return;

    const newFeedback: FeedbackItem = {
      id: Date.now().toString(),
      driverId: driver.id,
      driverName: driver.name,
      busRoute: driver.route,
      rating,
      comment,
      date: new Date().toISOString().split('T')[0],
      userType,
      userName: userEmail.split('@')[0],
    };

    setFeedbackList([newFeedback, ...feedbackList]);
    
    // Reset form
    setSelectedDriver('');
    setRating(0);
    setComment('');
    setActiveTab('history');
  };

  const filteredFeedback = filterDriver === 'all' 
    ? feedbackList 
    : feedbackList.filter(f => f.driverId === filterDriver);

  const getAverageRating = (driverId: string) => {
    const driverFeedback = feedbackList.filter(f => f.driverId === driverId);
    if (driverFeedback.length === 0) return 0;
    const sum = driverFeedback.reduce((acc, f) => acc + f.rating, 0);
    return (sum / driverFeedback.length).toFixed(1);
  };

  const getFeedbackCount = (driverId: string) => {
    return feedbackList.filter(f => f.driverId === driverId).length;
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="bg-slate-900/60 backdrop-blur-xl rounded-2xl shadow-xl p-6 border border-white/10">
        <div className="flex items-center gap-3 mb-2">
          <div className="w-12 h-12 bg-gradient-to-br from-cyan-500 to-blue-500 rounded-xl flex items-center justify-center shadow-lg shadow-cyan-500/20">
            <MessageSquare className="w-6 h-6 text-white" />
          </div>
          <div>
            <h2 className="text-white">Driver Feedback</h2>
            <p className="text-sm text-blue-200/60">Share your experience and help improve our bus services</p>
          </div>
        </div>
      </div>

      {/* Tab Navigation */}
      <div className="flex gap-2 bg-slate-900/60 backdrop-blur-xl rounded-xl p-1 border border-white/10">
        <button
          onClick={() => setActiveTab('submit')}
          className={`flex-1 py-3 px-4 rounded-lg font-medium transition-all duration-200 $\{
            activeTab === 'submit'
              ? 'bg-gradient-to-r from-cyan-500 to-blue-500 text-white shadow-lg shadow-cyan-500/20'
              : 'text-blue-200/70 hover:text-white hover:bg-white/5'
          }`}
        >
          Submit Feedback
        </button>
        <button
          onClick={() => setActiveTab('history')}
          className={`flex-1 py-3 px-4 rounded-lg font-medium transition-all duration-200 $\{
            activeTab === 'history'
              ? 'bg-gradient-to-r from-cyan-500 to-blue-500 text-white shadow-lg shadow-cyan-500/20'
              : 'text-blue-200/70 hover:text-white hover:bg-white/5'
          }`}
        >
          Feedback History
        </button>
      </div>

      {/* Submit Feedback Form */}
      {activeTab === 'submit' && (
        <div className="bg-slate-900/60 backdrop-blur-xl rounded-2xl shadow-xl p-6 border border-white/10 animate-scale-in">
          <form onSubmit={handleSubmitFeedback} className="space-y-6">
            {/* Driver Selection */}
            <div>
              <label className="block text-sm text-white/90 mb-2">
                Select Driver
              </label>
              <select
                value={selectedDriver}
                onChange={(e) => setSelectedDriver(e.target.value)}
                className="w-full px-4 py-3 border border-white/10 bg-white/5 text-white rounded-xl focus:ring-2 focus:ring-cyan-400/50 focus:border-cyan-400/50 backdrop-blur-sm hover:bg-white/[0.07] transition-all"
                required
              >
                <option value="" className="bg-slate-800">Select a driver...</option>
                {drivers.map(driver => (
                  <option key={driver.id} value={driver.id} className="bg-slate-800">
                    {driver.name} - {driver.route}
                  </option>
                ))}
              </select>
            </div>

            {/* Rating Selection */}
            <div>
              <label className="block text-sm text-white/90 mb-3">
                Rate Your Experience
              </label>
              <div className="flex items-center gap-2">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    type="button"
                    onClick={() => setRating(star)}
                    onMouseEnter={() => setHoverRating(star)}
                    onMouseLeave={() => setHoverRating(0)}
                    className="group transition-all duration-200 hover:scale-110 active:scale-95"
                  >
                    <Star
                      className={`w-10 h-10 transition-all duration-200 $\{
                        star <= (hoverRating || rating)
                          ? 'text-yellow-400 fill-yellow-400 drop-shadow-[0_0_8px_rgba(250,204,21,0.5)]'
                          : 'text-slate-600 group-hover:text-slate-500'
                      }`}
                    />
                  </button>
                ))}
                {rating > 0 && (
                  <span className="ml-3 text-cyan-400 font-medium animate-slide-in">
                    {rating === 5 ? 'Excellent!' : rating === 4 ? 'Great!' : rating === 3 ? 'Good' : rating === 2 ? 'Fair' : 'Poor'}
                  </span>
                )}
              </div>
            </div>

            {/* Comment */}
            <div>
              <label className="block text-sm text-white/90 mb-2">
                Your Feedback (Optional)
              </label>
              <textarea
                value={comment}
                onChange={(e) => setComment(e.target.value)}
                className="w-full px-4 py-3 border border-white/10 bg-white/5 text-white rounded-xl focus:ring-2 focus:ring-cyan-400/50 focus:border-cyan-400/50 placeholder-blue-300/30 backdrop-blur-sm hover:bg-white/[0.07] transition-all resize-none"
                rows={4}
                placeholder="Share your thoughts about the driver's service..."
              />
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              className="w-full bg-gradient-to-r from-cyan-500 to-blue-500 text-white py-3.5 px-6 rounded-xl font-medium hover:from-cyan-400 hover:to-blue-400 active:scale-[0.98] transition-all duration-200 shadow-lg shadow-cyan-500/20 flex items-center justify-center gap-2"
            >
              <Send className="w-5 h-5" />
              Submit Feedback
            </button>
          </form>
        </div>
      )}

      {/* Feedback History */}
      {activeTab === 'history' && (
        <div className="space-y-4 animate-scale-in">
          {/* Filter */}
          <div className="bg-slate-900/60 backdrop-blur-xl rounded-2xl shadow-xl p-4 border border-white/10">
            <label className="block text-sm text-white/90 mb-2">
              Filter by Driver
            </label>
            <select
              value={filterDriver}
              onChange={(e) => setFilterDriver(e.target.value)}
              className="w-full px-4 py-2.5 border border-white/10 bg-white/5 text-white rounded-xl focus:ring-2 focus:ring-cyan-400/50 focus:border-cyan-400/50 backdrop-blur-sm hover:bg-white/[0.07] transition-all"
            >
              <option value="all" className="bg-slate-800">All Drivers</option>
              {drivers.map(driver => (
                <option key={driver.id} value={driver.id} className="bg-slate-800">
                  {driver.name} - Avg: {getAverageRating(driver.id)} ⭐ ({getFeedbackCount(driver.id)} reviews)
                </option>
              ))}
            </select>
          </div>

          {/* Feedback List */}
          {filteredFeedback.length === 0 ? (
            <div className="bg-slate-900/60 backdrop-blur-xl rounded-2xl shadow-xl p-12 border border-white/10 text-center animate-fade-in">
              <div className="w-16 h-16 bg-blue-500/10 rounded-full flex items-center justify-center mx-auto mb-4 border border-blue-400/20">
                <MessageSquare className="w-8 h-8 text-blue-400/60" />
              </div>
              <p className="text-blue-200/60 mb-1">No feedback yet</p>
              <p className="text-sm text-blue-200/40">Be the first to share your experience!</p>
            </div>
          ) : (
            <div className="space-y-4">
              {filteredFeedback.map((feedback, index) => (
                <div 
                  key={feedback.id} 
                  className="bg-slate-900/60 backdrop-blur-xl rounded-2xl shadow-xl p-6 border border-white/10 hover:border-cyan-400/30 transition-all duration-300 animate-slide-in"
                  style={{ animationDelay: `${index * 50}ms` }}
                >
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-start gap-3">
                      <div className="w-10 h-10 bg-gradient-to-br from-cyan-500/20 to-blue-500/20 rounded-full flex items-center justify-center border border-cyan-400/30">
                        <User className="w-5 h-5 text-cyan-400" />
                      </div>
                      <div>
                        <h3 className="font-medium text-white">{feedback.driverName}</h3>
                        <p className="text-xs text-blue-200/50 mt-0.5">{feedback.busRoute}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="flex items-center gap-1 mb-1">
                        {Array.from({ length: 5 }).map((_, i) => (
                          <Star
                            key={i}
                            className={`w-4 h-4 $\{
                              i < feedback.rating ? 'text-yellow-400 fill-yellow-400' : 'text-slate-600'
                            }`}
                          />
                        ))}
                      </div>
                      <p className="text-xs text-blue-200/50">{feedback.date}</p>
                    </div>
                  </div>

                  {feedback.comment && (
                    <div className="bg-white/5 rounded-lg p-4 mb-3 border border-white/10">
                      <p className="text-sm text-blue-200/80">{feedback.comment}</p>
                    </div>
                  )}

                  <div className="flex items-center justify-between pt-3 border-t border-white/10">
                    <div className="flex items-center gap-2">
                      <span className={`px-3 py-1 rounded-full text-xs font-medium border $\{
                        feedback.userType === 'student' 
                          ? 'bg-cyan-500/10 text-cyan-400 border-cyan-400/30' 
                          : 'bg-purple-500/10 text-purple-400 border-purple-400/30'
                      }`}>
                        {feedback.userType === 'student' ? 'Student' : 'Parent'}
                      </span>
                      <span className="text-xs text-blue-200/50">by {feedback.userName}</span>
                    </div>
                    <button className="text-xs text-blue-200/50 hover:text-cyan-400 transition-colors flex items-center gap-1">
                      <ThumbsUp className="w-3.5 h-3.5" />
                      Helpful
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}