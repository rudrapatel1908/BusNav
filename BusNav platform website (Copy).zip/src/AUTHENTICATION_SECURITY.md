# BusNav Authentication & Security

## 🔐 **Credential-Based Authentication ONLY**

BusNav uses **strict email/password authentication**. Users can **ONLY** login with the credentials they created during signup.

---

## ✅ **How It Works**

### 1. **Account Creation (Signup)**
When a user creates an account:

```typescript
await signUp('student@example.com', 'password123', 'John Doe', 'student');
```

**What happens:**
- ✅ Email is **normalized to lowercase** to prevent duplicates
- ✅ Email **uniqueness is enforced** (no duplicate accounts)
- ✅ Password is **securely hashed** by Supabase Auth
- ✅ Account is **tied exclusively to these credentials**
- ✅ A unique **user ID (UUID)** is generated
- ✅ User profile is created in the database

**Security validations:**
- Email format validation
- Password minimum 6 characters
- Role must be 'student' or 'parent'
- Email uniqueness check (case-insensitive)
- Automatic rollback if profile creation fails

### 2. **Login (Sign In)**
Users can **ONLY** login with their exact credentials:

```typescript
await signIn('student@example.com', 'password123');
```

**What happens:**
- ✅ Supabase Auth **verifies the password hash**
- ✅ If credentials match → **session token is issued**
- ✅ If credentials don't match → **login fails**
- ❌ **No other login methods work** (no social login, no magic links)

**Security features:**
- Password hashing with bcrypt
- Secure session tokens (JWT)
- Automatic token refresh
- Session persistence in browser storage

### 3. **Session Management**
Once logged in:

```typescript
const { session } = await getSession();
const accessToken = session?.access_token;
```

**Security features:**
- ✅ Sessions are **tied to the user's credentials**
- ✅ Access tokens **expire automatically**
- ✅ Tokens are **auto-refreshed** when needed
- ✅ Sessions **persist across page refreshes**
- ✅ Users can **sign out** to invalidate their session

---

## 🛡️ **Security Measures**

### **Backend Security**

#### 1. **Row Level Security (RLS)**
Every table has RLS policies:

```sql
-- Users can ONLY view their own profile
CREATE POLICY "Users can view own profile"
  ON profiles FOR SELECT
  USING (auth.uid() = id);

-- Users can ONLY update their own profile
CREATE POLICY "Users can update own profile"
  ON profiles FOR UPDATE
  USING (auth.uid() = id);
```

**What this means:**
- ✅ User A **cannot** view User B's data
- ✅ User A **cannot** modify User B's data
- ✅ Users **cannot** change their email or role
- ✅ Protected from unauthorized access

#### 2. **Email Uniqueness**
```sql
CREATE UNIQUE INDEX profiles_email_unique_idx ON profiles (LOWER(email));
```

**What this means:**
- ✅ One account per email address
- ✅ Case-insensitive (student@test.com = STUDENT@test.com)
- ✅ Prevents duplicate accounts

#### 3. **Password Security**
- ✅ Passwords are **hashed using bcrypt** (industry standard)
- ✅ Original passwords are **never stored**
- ✅ Minimum 6 characters enforced
- ✅ Password reset capability (if email is configured)

#### 4. **Protected Endpoints**
All user-specific endpoints require authentication:

```typescript
// ❌ Without auth token → 401 Unauthorized
// ✅ With valid token → Success

await fetch('/user/profile', {
  headers: {
    'Authorization': `Bearer ${accessToken}`
  }
});
```

**Protected endpoints:**
- `/user/profile` - Get user profile
- `/user/university` - Save university selection
- `/user/location` - Save home location
- `/user/pickup-route` - Save/get pickup routes
- `/feedback` - Submit driver feedback

### **Frontend Security**

#### 1. **Secure Client Configuration**
```typescript
createClient(supabaseUrl, publicAnonKey, {
  auth: {
    autoRefreshToken: true,      // Auto-refresh expired tokens
    persistSession: true,          // Save session in browser
    detectSessionInUrl: false      // Disable OAuth redirects
  }
});
```

#### 2. **Token Storage**
- ✅ Session tokens stored in **localStorage** (persistent)
- ✅ Tokens are **httpOnly cookies** on server-side
- ✅ Automatic cleanup on logout

#### 3. **API Helpers with Auth**
```typescript
// All API functions automatically include auth when needed
export async function getUserProfile() {
  const accessToken = await getAccessToken(); // Auto-retrieves from session
  if (!accessToken) throw new Error('Not authenticated');
  // ... makes authenticated request
}
```

---

## 🚫 **What's NOT Allowed**

### **NO Social Login**
- ❌ Cannot login with Google
- ❌ Cannot login with Facebook
- ❌ Cannot login with GitHub
- ✅ **ONLY email/password** is allowed

### **NO Magic Links**
- ❌ Cannot login with email magic links
- ✅ **ONLY password-based login** works

### **NO Account Sharing**
- ❌ One user cannot access another user's account
- ❌ Sessions cannot be transferred between users
- ✅ Each user has **their own isolated data**

### **NO Email/Role Changes**
```sql
CREATE POLICY "Users cannot change email or role"
  WITH CHECK (
    email = (SELECT email FROM profiles WHERE id = auth.uid()) AND
    role = (SELECT role FROM profiles WHERE id = auth.uid())
  );
```

- ❌ Users cannot change their email address
- ❌ Users cannot change their role (student ↔ parent)
- ✅ Prevents account takeover attempts

---

## 📱 **Usage Example**

### **Complete Authentication Flow**

```typescript
import * as API from './utils/api';

// 1. SIGNUP - Create new account
try {
  const result = await API.signUp(
    'student@university.edu',
    'SecurePass123',
    'John Doe',
    'student'
  );
  console.log('Account created:', result.message);
  // "Account created successfully! You can now login with your credentials."
} catch (error) {
  console.error(error.message);
  // "An account with this email already exists. Please login instead."
}

// 2. LOGIN - Sign in with credentials
try {
  const { user, access_token } = await API.signIn(
    'student@university.edu',
    'SecurePass123'
  );
  console.log('Logged in as:', user.email);
  // Session is now active, token stored automatically
} catch (error) {
  console.error(error.message);
  // "Invalid login credentials"
}

// 3. ACCESS PROTECTED DATA - Auto-authenticated
try {
  const { profile } = await API.getUserProfile();
  console.log('User profile:', profile);
  // Returns user's profile data
} catch (error) {
  console.error(error.message);
  // "Not authenticated" (if not logged in)
}

// 4. LOGOUT - End session
try {
  await API.signOut();
  console.log('Logged out successfully');
  // Session token is cleared
} catch (error) {
  console.error(error.message);
}
```

---

## 🔍 **Testing the Security**

### **Test 1: Duplicate Email Prevention**
```typescript
// Create first account
await signUp('test@test.com', 'pass123', 'User 1', 'student');
// ✅ Success

// Try to create second account with same email
await signUp('test@test.com', 'different', 'User 2', 'parent');
// ❌ Error: "An account with this email already exists"
```

### **Test 2: Wrong Password**
```typescript
await signUp('test@test.com', 'correct123', 'User', 'student');
// ✅ Account created

await signIn('test@test.com', 'wrong_password');
// ❌ Error: "Invalid login credentials"
```

### **Test 3: Unauthorized Access**
```typescript
// Login as User A
await signIn('userA@test.com', 'passA');
const { profile: profileA } = await getUserProfile();
// ✅ Returns User A's profile

// Try to access User B's data (using User A's token)
// Row Level Security prevents this at the database level
// ✅ RLS blocks the query, returns nothing
```

### **Test 4: Session Persistence**
```typescript
// Login
await signIn('test@test.com', 'pass123');

// Refresh the page
window.location.reload();

// Session still active
const { session } = await getSession();
console.log('Still logged in:', session !== null);
// ✅ true
```

---

## 📊 **Database Security Architecture**

```
┌─────────────────────────────────────────────┐
│           Supabase Auth Layer               │
│  - Password hashing (bcrypt)                │
│  - JWT token generation                     │
│  - Session management                       │
└─────────────────────────────────────────────┘
                    ↓
┌─────────────────────────────────────────────┐
│      Row Level Security (RLS) Layer         │
│  - auth.uid() = profile.id check            │
│  - Per-row access control                   │
│  - Prevents unauthorized queries            │
└─────────────────────────────────────────────┘
                    ↓
┌─────────────────────────────────────────────┐
│            Database Tables                  │
│  - profiles (user data)                     │
│  - user_pickup_routes (user routes)         │
│  - feedback (user reviews)                  │
└─────────────────────────────────────────────┘
```

---

## ✅ **Summary**

**BusNav Authentication is:**
- 🔐 **Credential-based only** - Email/password required
- 🛡️ **Secure** - Industry-standard encryption
- 🚫 **No alternatives** - No social login, no magic links
- 👤 **User-isolated** - Each user sees only their data
- 🔒 **Protected** - Row Level Security on all tables
- ✅ **Production-ready** - Meets security best practices

**Users can ONLY login with the credentials they created during signup. No exceptions.**

---

Need help with integration? Check the main [SUPABASE_SETUP.md](./SUPABASE_SETUP.md) guide!
