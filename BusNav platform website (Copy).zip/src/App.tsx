import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Login } from './components/Login';
import { UniversitySelection } from './components/UniversitySelection';
import { BusTracker } from './components/BusTracker';
import { DriverInfo } from './components/DriverInfo';
import { Notifications } from './components/Notifications';
import { Feedback } from './components/Feedback';
import logo from 'figma:asset/c318be13d83ec253d11a3c8f71f277389266d69b.png';

export default function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [userType, setUserType] = useState<'student' | 'parent'>('student');
  const [userEmail, setUserEmail] = useState('');
  const [selectedUniversity, setSelectedUniversity] = useState<string | null>(null);
  const [currentView, setCurrentView] = useState<'tracker' | 'drivers' | 'notifications' | 'feedback'>('tracker');
  const [userLocation, setUserLocation] = useState({ lat: 16.4381, lng: 80.5980 }); // Default to SRM AP University area

  const handleLogin = (type: 'student' | 'parent', email: string) => {
    setUserType(type);
    setUserEmail(email);
    setIsAuthenticated(true);
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    setSelectedUniversity(null);
    setUserEmail('');
  };

  if (!isAuthenticated) {
    return <Login onLogin={handleLogin} />;
  }

  if (!selectedUniversity) {
    return <UniversitySelection onSelect={setSelectedUniversity} />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-blue-950 to-slate-900">
      {/* Header */}
      <motion.header 
        initial={{ y: -20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.5 }}
        className="bg-slate-900/70 backdrop-blur-xl border-b border-white/10 shadow-xl sticky top-0 z-50"
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center gap-4">
              <motion.div 
                className="relative group"
                whileHover={{ scale: 1.1, rotate: 360 }}
                transition={{ duration: 0.6 }}
              >
                <div className="absolute inset-0 bg-cyan-500/20 blur-lg rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                <img src={logo} alt="BusNav Logo" className="w-12 h-12 object-contain relative z-10" />
              </motion.div>
              <div>
                <motion.h1 
                  initial={{ x: -20, opacity: 0 }}
                  animate={{ x: 0, opacity: 1 }}
                  transition={{ delay: 0.2 }}
                  className="font-semibold text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-400 tracking-wide"
                >
                  BusNav
                </motion.h1>
                <div className="flex items-center gap-2">
                  <p className="text-sm text-blue-200/70">{selectedUniversity}</p>
                  <div className="flex items-center gap-1">
                    <div className="w-1.5 h-1.5 bg-green-400 rounded-full live-indicator"></div>
                    <span className="text-xs text-green-400/80">Live</span>
                  </div>
                </div>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <motion.div 
                initial={{ x: 20, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                transition={{ delay: 0.3 }}
                className="text-right hidden sm:block"
              >
                <div className="text-sm text-white/90">{userEmail}</div>
                <div className="text-xs text-blue-300/50 capitalize">{userType}</div>
              </motion.div>
              <motion.div 
                className="flex gap-2"
                initial={{ x: 20, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                transition={{ delay: 0.4 }}
              >
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => setSelectedUniversity(null)}
                  className="text-sm text-blue-200 hover:text-white px-4 py-2 rounded-xl hover:bg-white/10 transition-all duration-200 border border-white/10"
                >
                  Change University
                </motion.button>
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={handleLogout}
                  className="text-sm text-white bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-400 hover:to-blue-400 px-4 py-2 rounded-xl transition-all duration-200 shadow-lg shadow-cyan-500/20"
                >
                  Logout
                </motion.button>
              </motion.div>
            </div>
          </div>
        </div>
      </motion.header>

      {/* Navigation Tabs */}
      <nav className="bg-slate-900/50 backdrop-blur-xl border-b border-white/10 sticky top-[72px] z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex gap-3 py-3">
            <motion.button
              whileHover={{ scale: 1.05, y: -2 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setCurrentView('tracker')}
              className={`py-3 px-6 font-medium text-sm transition-all duration-200 rounded-xl border ${
                currentView === 'tracker'
                  ? 'text-cyan-400 bg-cyan-500/10 border-cyan-400/50 shadow-lg shadow-cyan-500/20'
                  : 'text-gray-300 bg-white/5 border-white/10 hover:text-white hover:bg-white/10 hover:border-white/20 hover:shadow-lg'
              }`}
            >
              <span className="flex items-center gap-2">
                Bus Tracker
                {currentView === 'tracker' && (
                  <div className="w-1.5 h-1.5 bg-cyan-400 rounded-full live-indicator"></div>
                )}
              </span>
            </motion.button>
            <motion.button
              whileHover={{ scale: 1.05, y: -2 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setCurrentView('drivers')}
              className={`py-3 px-6 font-medium text-sm transition-all duration-200 rounded-xl border ${
                currentView === 'drivers'
                  ? 'text-cyan-400 bg-cyan-500/10 border-cyan-400/50 shadow-lg shadow-cyan-500/20'
                  : 'text-gray-300 bg-white/5 border-white/10 hover:text-white hover:bg-white/10 hover:border-white/20 hover:shadow-lg'
              }`}
            >
              Driver Information
            </motion.button>
            <motion.button
              whileHover={{ scale: 1.05, y: -2 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setCurrentView('notifications')}
              className={`py-3 px-6 font-medium text-sm transition-all duration-200 rounded-xl border ${
                currentView === 'notifications'
                  ? 'text-cyan-400 bg-cyan-500/10 border-cyan-400/50 shadow-lg shadow-cyan-500/20'
                  : 'text-gray-300 bg-white/5 border-white/10 hover:text-white hover:bg-white/10 hover:border-white/20 hover:shadow-lg'
              }`}
            >
              Notifications
            </motion.button>
            <motion.button
              whileHover={{ scale: 1.05, y: -2 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setCurrentView('feedback')}
              className={`py-3 px-6 font-medium text-sm transition-all duration-200 rounded-xl border ${
                currentView === 'feedback'
                  ? 'text-cyan-400 bg-cyan-500/10 border-cyan-400/50 shadow-lg shadow-cyan-500/20'
                  : 'text-gray-300 bg-white/5 border-white/10 hover:text-white hover:bg-white/10 hover:border-white/20 hover:shadow-lg'
              }`}
            >
              Feedback
            </motion.button>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <AnimatePresence>
          {currentView === 'tracker' && (
            <motion.div
              key="tracker"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 20 }}
              transition={{ duration: 0.3 }}
            >
              <BusTracker 
                university={selectedUniversity} 
                userLocation={userLocation}
                onLocationChange={setUserLocation}
              />
            </motion.div>
          )}
          {currentView === 'drivers' && (
            <motion.div
              key="drivers"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 20 }}
              transition={{ duration: 0.3 }}
            >
              <DriverInfo university={selectedUniversity} />
            </motion.div>
          )}
          {currentView === 'notifications' && (
            <motion.div
              key="notifications"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 20 }}
              transition={{ duration: 0.3 }}
            >
              <Notifications userLocation={userLocation} />
            </motion.div>
          )}
          {currentView === 'feedback' && (
            <motion.div
              key="feedback"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 20 }}
              transition={{ duration: 0.3 }}
            >
              <Feedback 
                university={selectedUniversity}
                userType={userType}
                userEmail={userEmail}
              />
            </motion.div>
          )}
        </AnimatePresence>
      </main>
    </div>
  );
}