import { projectId, publicAnonKey } from './supabase/info';
import { getAccessToken, createClient } from './supabase/client';

const SERVER_URL = `https://${projectId}.supabase.co/functions/v1/make-server-8828d0dd`;

// ============================================
// AUTH API
// ============================================

/**
 * Sign up a new user with email and password
 * Creates a unique account that can ONLY be accessed with these credentials
 */
export async function signUp(
  email: string, 
  password: string, 
  name: string, 
  role: 'student' | 'parent',
  rollNumber?: string,
  phoneNumber?: string,
  emergencyPhone?: string
) {
  const response = await fetch(`${SERVER_URL}/auth/signup`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${publicAnonKey}`
    },
    body: JSON.stringify({ 
      email, 
      password, 
      name, 
      role,
      roll_number: rollNumber,
      phone_number: phoneNumber,
      emergency_phone: emergencyPhone
    })
  });

  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.error || 'Signup failed');
  }

  return response.json();
}

/**
 * Sign in with email and password
 * ONLY works with credentials created during signup
 * No other authentication methods are allowed
 */
export async function signIn(email: string, password: string) {
  const supabase = createClient();
  
  const { data, error } = await supabase.auth.signInWithPassword({
    email,
    password
  });

  if (error) {
    throw new Error(error.message || 'Login failed');
  }

  if (!data.session) {
    throw new Error('Invalid credentials');
  }

  return {
    user: data.user,
    session: data.session,
    access_token: data.session.access_token
  };
}

/**
 * Sign out the current user
 */
export async function signOut() {
  const supabase = createClient();
  
  const { error } = await supabase.auth.signOut();
  
  if (error) {
    throw new Error(error.message || 'Signout failed');
  }

  return { success: true };
}

/**
 * Check if user is currently authenticated
 */
export async function isAuthenticated() {
  const supabase = createClient();
  const { data: { session } } = await supabase.auth.getSession();
  return !!session;
}

// ============================================
// UNIVERSITIES API
// ============================================

export async function getAllUniversities() {
  const response = await fetch(`${SERVER_URL}/universities`, {
    headers: {
      'Authorization': `Bearer ${publicAnonKey}`
    }
  });

  if (!response.ok) {
    throw new Error('Failed to fetch universities');
  }

  return response.json();
}

export async function getUniversity(id: string) {
  const response = await fetch(`${SERVER_URL}/universities/${id}`, {
    headers: {
      'Authorization': `Bearer ${publicAnonKey}`
    }
  });

  if (!response.ok) {
    throw new Error('Failed to fetch university');
  }

  return response.json();
}

// ============================================
// BUS TRACKING API
// ============================================

export async function updateBusLocation(busId: string, latitude: number, longitude: number) {
  const response = await fetch(`${SERVER_URL}/buses/${busId}/location`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${publicAnonKey}`
    },
    body: JSON.stringify({ latitude, longitude })
  });

  if (!response.ok) {
    throw new Error('Failed to update bus location');
  }

  return response.json();
}

export async function getBusLocations(universityId: string) {
  const response = await fetch(`${SERVER_URL}/universities/${universityId}/bus-locations`, {
    headers: {
      'Authorization': `Bearer ${publicAnonKey}`
    }
  });

  if (!response.ok) {
    throw new Error('Failed to fetch bus locations');
  }

  return response.json();
}

// ============================================
// USER PREFERENCES API (Requires Auth)
// ============================================

export async function saveUserUniversity(universityId: string) {
  const accessToken = await getAccessToken();
  if (!accessToken) throw new Error('Not authenticated');

  const response = await fetch(`${SERVER_URL}/user/university`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${accessToken}`
    },
    body: JSON.stringify({ university_id: universityId })
  });

  if (!response.ok) {
    throw new Error('Failed to save university');
  }

  return response.json();
}

export async function saveUserLocation(latitude: number, longitude: number, address?: string) {
  const accessToken = await getAccessToken();
  if (!accessToken) throw new Error('Not authenticated');

  const response = await fetch(`${SERVER_URL}/user/location`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${accessToken}`
    },
    body: JSON.stringify({ latitude, longitude, address })
  });

  if (!response.ok) {
    throw new Error('Failed to save location');
  }

  return response.json();
}

export async function getUserProfile() {
  const accessToken = await getAccessToken();
  if (!accessToken) throw new Error('Not authenticated');

  const response = await fetch(`${SERVER_URL}/user/profile`, {
    headers: {
      'Authorization': `Bearer ${accessToken}`
    }
  });

  if (!response.ok) {
    throw new Error('Failed to fetch profile');
  }

  return response.json();
}

// ============================================
// PICKUP ROUTES API (Requires Auth)
// ============================================

export async function savePickupRoute(busId: string, latitude: number, longitude: number) {
  const accessToken = await getAccessToken();
  if (!accessToken) throw new Error('Not authenticated');

  const response = await fetch(`${SERVER_URL}/user/pickup-route`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${accessToken}`
    },
    body: JSON.stringify({
      bus_id: busId,
      pickup_latitude: latitude,
      pickup_longitude: longitude
    })
  });

  if (!response.ok) {
    throw new Error('Failed to save pickup route');
  }

  return response.json();
}

export async function getPickupRoute() {
  const accessToken = await getAccessToken();
  if (!accessToken) throw new Error('Not authenticated');

  const response = await fetch(`${SERVER_URL}/user/pickup-route`, {
    headers: {
      'Authorization': `Bearer ${accessToken}`
    }
  });

  if (!response.ok) {
    throw new Error('Failed to fetch pickup route');
  }

  return response.json();
}

// ============================================
// FEEDBACK API (Requires Auth)
// ============================================

export async function submitFeedback(driverId: string, rating: number, comment?: string) {
  const accessToken = await getAccessToken();
  if (!accessToken) throw new Error('Not authenticated');

  const response = await fetch(`${SERVER_URL}/feedback`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${accessToken}`
    },
    body: JSON.stringify({ driver_id: driverId, rating, comment })
  });

  if (!response.ok) {
    throw new Error('Failed to submit feedback');
  }

  return response.json();
}

export async function getDriverFeedback(driverId: string) {
  const response = await fetch(`${SERVER_URL}/drivers/${driverId}/feedback`, {
    headers: {
      'Authorization': `Bearer ${publicAnonKey}`
    }
  });

  if (!response.ok) {
    throw new Error('Failed to fetch feedback');
  }

  return response.json();
}